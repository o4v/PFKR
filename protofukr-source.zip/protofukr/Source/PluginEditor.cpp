#include "PluginEditor.h"
#include "Presets.h"

using namespace ui;

// ============================================================================ widgets
Knob::Knob (APVTS& s, const juce::String& id, const juce::String& caption, juce::Colour accent, bool isSmall) : compact (isSmall)
{
    slider.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    slider.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 60, 18);
    slider.setColour (juce::Slider::rotarySliderFillColourId, accent);
    slider.setMouseDragSensitivity (220);   // original feel; hold Shift while dragging for fine control
    slider.setVelocityModeParameters (0.35, 1, 0.0, true, juce::ModifierKeys::shiftModifier);
    att = std::make_unique<APVTS::SliderAttachment> (s, id, slider);
    if (auto* prm = s.getParameter (id))
    {
        slider.setDoubleClickReturnValue (true, prm->convertFrom0to1 (prm->getDefaultValue()));
        slider.setTooltip (prm->getName (64) + "  (drag, Shift+drag for fine, scroll, or click the value to type it; double-click resets)");
    }
    cap.setText (caption, juce::dontSendNotification);
    cap.setJustificationType (juce::Justification::centred);
    cap.setFont (theme::label (10.5f));
    cap.setColour (juce::Label::textColourId, theme::inkSoft);
    cap.setInterceptsMouseClicks (false, false);
    addAndMakeVisible (slider);
    addAndMakeVisible (cap);
}

void Knob::resized()
{
    auto b = getLocalBounds();
    cap.setBounds (b.removeFromTop (13));
    slider.setTextBoxStyle (juce::Slider::TextBoxBelow, false, juce::jmin (b.getWidth() - 2, 66), 18);
    slider.setBounds (b);
}

Fader::Fader (APVTS& s, const juce::String& id, const juce::String& caption, juce::Colour accent)
{
    slider.setSliderStyle (juce::Slider::LinearVertical);
    slider.setTextBoxStyle (juce::Slider::TextBoxAbove, false, 70, 20);
    slider.setColour (juce::Slider::rotarySliderFillColourId, accent);
    att = std::make_unique<APVTS::SliderAttachment> (s, id, slider);
    if (auto* prm = s.getParameter (id))
    {
        slider.setDoubleClickReturnValue (true, prm->convertFrom0to1 (prm->getDefaultValue()));
        slider.setTooltip (prm->getName (64) + "  (click the readout to type an exact value)");
    }
    cap.setText (caption, juce::dontSendNotification);
    cap.setJustificationType (juce::Justification::centred);
    cap.setFont (theme::label (10.5f));
    cap.setColour (juce::Label::textColourId, theme::inkSoft);
    addAndMakeVisible (slider);
    addAndMakeVisible (cap);
    pick.setColour (juce::TextButton::buttonOnColourId, accent);
    pick.setTooltip ("Common values");
    pick.onClick = [this]
    {
        juce::PopupMenu m;
        for (size_t i = 0; i < picks.size(); ++i) m.addItem ((int) i + 1, picks[i].first);
        m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&pick), [this] (int r)
        {
            if (r > 0 && pickCb) pickCb (picks[(size_t) r - 1].second);
        });
    };
}

void Fader::setPicks (std::vector<std::pair<juce::String, float>> p, std::function<void (float)> cb)
{
    picks = std::move (p); pickCb = std::move (cb);
    addAndMakeVisible (pick);
    resized();
}

void Fader::resized()
{
    auto b = getLocalBounds();
    auto bottom = b.removeFromBottom (18);
    if (pick.isVisible()) pick.setBounds (bottom.removeFromRight (18).reduced (1));
    cap.setBounds (bottom);
    slider.setBounds (b);
}

Segmented::Segmented (APVTS& s, const juce::String& id, const juce::StringArray& labels, juce::Colour accent)
{
    for (int i = 0; i < labels.size(); ++i)
    {
        auto* b = buttons.add (new juce::TextButton (labels[i]));
        b->setColour (juce::TextButton::buttonOnColourId, accent);
        b->setConnectedEdges ((i > 0 ? juce::Button::ConnectedOnLeft : 0) | (i < labels.size() - 1 ? juce::Button::ConnectedOnRight : 0));
        b->onClick = [this, i] { if (att) att->setValueAsCompleteGesture ((float) i); };
        addAndMakeVisible (b);
    }
    if (auto* prm = s.getParameter (id))
    {
        att = std::make_unique<juce::ParameterAttachment> (*prm, [this] (float v) { update (v); });
        att->sendInitialUpdate();
    }
}

void Segmented::update (float v)
{
    const int idx = (int) std::lround (v);
    for (int i = 0; i < buttons.size(); ++i) buttons[i]->setToggleState (i == idx, juce::dontSendNotification);
}

void Segmented::resized()
{
    auto b = getLocalBounds();
    const int n = buttons.size();
    for (int i = 0; i < n; ++i)
    {
        const int x0 = b.getX() + b.getWidth() * i / n, x1 = b.getX() + b.getWidth() * (i + 1) / n;
        buttons[i]->setBounds (x0, b.getY(), x1 - x0 + (i < n - 1 ? 1 : 0), b.getHeight());
    }
}

Combo::Combo (APVTS& s, const juce::String& id, const juce::StringArray& items)
{
    box.addItemList (items, 1);
    att = std::make_unique<APVTS::ComboBoxAttachment> (s, id, box);
    if (auto* prm = s.getParameter (id)) box.setTooltip (prm->getName (64));
    addAndMakeVisible (box);
}

Toggle::Toggle (APVTS& s, const juce::String& id, const juce::String& text, juce::Colour accent)
{
    b.setButtonText (text);
    b.setColour (juce::ToggleButton::tickColourId, accent.withSaturation (std::min (1.0f, accent.getSaturation() * 1.8f)));
    att = std::make_unique<APVTS::ButtonAttachment> (s, id, b);
    if (auto* prm = s.getParameter (id)) b.setTooltip (prm->getName (64));
    addAndMakeVisible (b);
}

void Panel::paint (juce::Graphics& g)
{
    auto r = getLocalBounds().toFloat().reduced (1.0f);
    g.setColour (juce::Colours::black.withAlpha (0.18f));
    g.fillRoundedRectangle (r.translated (0, 2.0f), 10.0f);
    juce::ColourGradient body (theme::chassisLight, 0, r.getY(), theme::chassis, 0, r.getBottom(), false);
    g.setGradientFill (body);
    g.fillRoundedRectangle (r, 10.0f);
    // brushed texture
    juce::Random rnd (42);
    for (float y = r.getY() + 32; y < r.getBottom() - 4; y += 2.0f)
    {
        g.setColour (juce::Colours::white.withAlpha (0.05f + 0.06f * rnd.nextFloat()));
        g.drawHorizontalLine ((int) y, r.getX() + 6, r.getRight() - 6);
    }
    g.setColour (juce::Colours::white.withAlpha (0.8f));
    g.drawRoundedRectangle (r.reduced (1.0f), 9.0f, 1.0f);
    g.setColour (theme::chassisDark);
    g.drawRoundedRectangle (r, 10.0f, 1.2f);

    // header strip
    auto hdr = r.removeFromTop (30.0f).reduced (4.0f, 4.0f);
    theme::glossFill (g, hdr, accent, 7.0f);
    g.setColour (theme::ink);
    g.setFont (theme::header (16.0f));
    g.drawText (title, hdr.withTrimmedLeft (10.0f), juce::Justification::centredLeft);
}

void WarpLcd::paint (juce::Graphics& g)
{
    auto r = getLocalBounds().toFloat();
    g.setColour (theme::lcdBg); g.fillRoundedRectangle (r, 5.0f);
    g.setColour (theme::lcdInk.withAlpha (0.08f));
    for (float x = r.getX() + 8; x < r.getRight(); x += 12) g.drawVerticalLine ((int) x, r.getY() + 2, r.getBottom() - 2);
    for (float y = r.getY() + 8; y < r.getBottom(); y += 12) g.drawHorizontalLine ((int) y, r.getX() + 2, r.getRight() - 2);

    auto& s = proc.apvts;
    const int mode = (int) s.getRawParameterValue (pid::warpMode)->load();
    const int algo = (int) s.getRawParameterValue (pid::warpAlgo)->load();
    const float speed = s.getRawParameterValue (pid::warpSpeed)->load();
    const float pitch = s.getRawParameterValue (pid::warpPitch)->load();
    auto plot = r.reduced (8.0f).withTrimmedTop (18.0f);
    g.setColour (theme::lcdInk);
    g.setFont (theme::lcd (18.0f));
    juce::String hdr = choices::warpMode[mode].toUpperCase() + "  " + choices::warpAlgo[algo].toUpperCase()
                     + "  x" + juce::String (speed, 3) + (algo == 3 ? juce::String() : "  " + juce::String (pitch, 1) + "st");
    g.drawText (hdr, r.reduced (8.0f, 3.0f).withHeight (18.0f), juce::Justification::centredLeft);

    if (mode == 0)
    {
        g.setFont (theme::lcd (26.0f));
        g.drawText ("- warp off -", plot, juce::Justification::centred);
        return;
    }
    if (mode == 2)
    {
        if (peaks.empty())
        {
            g.setFont (theme::lcd (20.0f));
            g.drawText ("drop a sample here", plot, juce::Justification::centred);
            return;
        }
        const float mid = plot.getCentreY(), hh = plot.getHeight() * 0.5f;
        const float w = plot.getWidth() / (float) peaks.size();
        for (size_t i = 0; i < peaks.size(); ++i)
        {
            const float v = juce::jmin (1.0f, peaks[i]) * hh;
            g.fillRect (plot.getX() + (float) i * w, mid - v, std::max (1.0f, w), std::max (1.0f, 2.0f * v));
        }
        const float ph = plot.getX() + proc.warpPlayhead.load() * plot.getWidth();
        g.setColour (theme::hot); g.fillRect (ph - 1.0f, plot.getY(), 2.0f, plot.getHeight());
        g.setColour (theme::lcdInk); g.setFont (theme::lcd (16.0f));
        g.drawText (sampleName, plot.removeFromBottom (14.0f), juce::Justification::centredRight);
        return;
    }
    // capture: scope + window position
    const int N = 512;
    const int w0 = proc.scopeWrite.load();
    juce::Path p;
    for (int i = 0; i < N; ++i)
    {
        const float v = proc.scope[(w0 - N * 2 + i * 2 + ProtofukrProcessor::kScopeSize * 2) & (ProtofukrProcessor::kScopeSize - 1)];
        const float x = plot.getX() + plot.getWidth() * (float) i / (float) (N - 1);
        const float y = plot.getCentreY() - juce::jlimit (-1.0f, 1.0f, v) * plot.getHeight() * 0.45f;
        if (i == 0) p.startNewSubPath (x, y); else p.lineTo (x, y);
    }
    g.strokePath (p, juce::PathStrokeType (1.4f));
    auto bar = plot.removeFromBottom (6.0f);
    g.setColour (theme::lcdInk.withAlpha (0.2f)); g.fillRect (bar);
    g.setColour (s.getRawParameterValue (pid::warpFreeze)->load() > 0.5f ? theme::hot : theme::lcdInk);
    g.fillRect (bar.withWidth (bar.getWidth() * proc.warpPlayhead.load()));
}

void LofiLcd::paint (juce::Graphics& g)
{
    auto r = getLocalBounds().toFloat();
    g.setColour (theme::lcdBg); g.fillRoundedRectangle (r, 5.0f);
    const double sr = proc.getSampleRate() > 0 ? proc.getSampleRate() : 44100.0;

    // spectrum of the output
    const int N = 2048;
    const int w0 = proc.scopeWrite.load();
    for (int i = 0; i < N; ++i)
    {
        const float win = 0.5f - 0.5f * std::cos (juce::MathConstants<float>::twoPi * (float) i / (float) (N - 1));
        work[(size_t) i] = proc.scope[(w0 + i) & (ProtofukrProcessor::kScopeSize - 1)] * win;
    }
    std::fill (work.begin() + N, work.end(), 0.0f);
    fft.performFrequencyOnlyForwardTransform (work.data(), true);
    auto plot = r.reduced (8.0f).withTrimmedTop (20.0f).withTrimmedBottom (2.0f);
    const float fLo = 40.0f, fHi = (float) std::min (20000.0, sr * 0.5);
    const int nb = (int) bars.size();
    const float bw = plot.getWidth() / (float) nb;
    g.setColour (theme::lcdInk);
    for (int b = 0; b < nb; ++b)
    {
        const float f0 = fLo * std::pow (fHi / fLo, (float) b / (float) nb), f1 = fLo * std::pow (fHi / fLo, (float) (b + 1) / (float) nb);
        const int k0 = juce::jlimit (1, N / 2 - 1, (int) (f0 / sr * N)), k1 = juce::jlimit (k0 + 1, N / 2, (int) (f1 / sr * N) + 1);
        float m = 0; for (int k = k0; k < k1; ++k) m = std::max (m, work[(size_t) k]);
        const float db = juce::Decibels::gainToDecibels (m / (float) N * 4.0f, -96.0f);
        const float v = juce::jlimit (0.0f, 1.0f, (db + 84.0f) / 84.0f);
        bars[(size_t) b] = std::max (v, bars[(size_t) b] * 0.86f);
        const float h = bars[(size_t) b] * plot.getHeight();
        // stepped LCD segments
        for (float y = plot.getBottom() - 3.0f; y > plot.getBottom() - h; y -= 4.0f)
            g.fillRect (plot.getX() + (float) b * bw + 0.5f, y, std::max (1.0f, bw - 1.5f), 2.5f);
    }
    // codec bandwidth marker
    auto& s = proc.apvts;
    const bool on = s.getRawParameterValue (pid::lofiOn)->load() > 0.5f;
    const int type = (int) s.getRawParameterValue (pid::codecType)->load();
    const float srT = s.getRawParameterValue (pid::codecSR)->load();
    const float kb = s.getRawParameterValue (pid::codecKbps)->load();
    float cut = on && type >= 3 ? proc.codecBandwidth.load() : (on && type >= 1 ? srT * 0.5f : fHi);
    if (cut < fHi)
    {
        const float x = plot.getX() + plot.getWidth() * std::log (cut / fLo) / std::log (fHi / fLo);
        g.setColour (theme::hot);
        for (float y = plot.getY(); y < plot.getBottom(); y += 6) g.fillRect (x - 1.0f, y, 2.0f, 3.0f);
        g.setFont (theme::lcd (15.0f));
        g.drawText (juce::String (cut / 1000.0f, 1) + "k", juce::Rectangle<float> (x + 3, plot.getY(), 40, 14), juce::Justification::left);
    }
    g.setColour (theme::lcdInk);
    g.setFont (theme::lcd (17.0f));
    juce::String info = on ? choices::codecType[type].toUpperCase() : juce::String ("BYPASS");
    if (on && type >= 1)
    {
        auto khz = juce::String (srT / 1000.0f, 2);
        while (khz.containsChar ('.') && (khz.endsWithChar ('0') || khz.endsWithChar ('.'))) khz = khz.dropLastCharacters (1);
        info << " " << khz << "k";
    }
    if (on && type >= 3) info << " " << juce::String ((int) kb) << "kbps";
    auto line = r.reduced (8.0f, 3.0f).withHeight (18.0f);
    const int lat = proc.codecHop.load();
    if (lat > 0) g.drawText (juce::String (juce::roundToInt (1000.0 * lat / sr)) + "ms", line, juce::Justification::centredRight);
    g.drawText (info, line, juce::Justification::centredLeft);
}

void Meter::paint (juce::Graphics& g)
{
    auto r = getLocalBounds().toFloat();
    g.setColour (theme::groove); g.fillRoundedRectangle (r, 3.0f);
    float v = get ? get() : 0.0f;
    float norm = reduction ? juce::jlimit (0.0f, 1.0f, v / 24.0f) : juce::jlimit (0.0f, 1.0f, (juce::Decibels::gainToDecibels (v, -60.0f) + 60.0f) / 66.0f);
    shown = std::max (norm, shown * 0.9f);
    auto fill = reduction ? r.reduced (2.0f).withHeight ((r.getHeight() - 4.0f) * shown)
                          : r.reduced (2.0f).withTrimmedTop ((r.getHeight() - 4.0f) * (1.0f - shown));
    g.setGradientFill (juce::ColourGradient (theme::mint, 0, r.getBottom(), theme::hot, 0, r.getY(), false));
    if (reduction) g.setColour (theme::hot);
    g.fillRoundedRectangle (fill, 2.0f);
}

// ============================================================================ editor
ProtofukrEditor::ProtofukrEditor (ProtofukrProcessor& p)
    : AudioProcessorEditor (&p), proc (p), warpLcd (p), lofiLcd (p)
{
    setLookAndFeel (&lnf);
    auto& s = proc.apvts;
    const auto lav = theme::lavender, pk = theme::pink, mn = theme::mint, pe = theme::peach, sk = theme::sky;

    for (auto* c : { &warpPanel, &lofiPanel, &tapePanel, &dynPanel, &fxPanel, &larpPanel, &outPanel }) root.addAndMakeVisible (c);

    // ---- top bar
    for (int i = 0; i < (int) factoryPresets().size(); ++i) presetBox.addItem (factoryPresets()[(size_t) i].name, i + 1);
    presetBox.setTextWhenNothingSelected ("presets");
    presetBox.onChange = [this] { const int id = presetBox.getSelectedId(); if (id > 0) { proc.applyPreset (id - 1); shownProgram = id - 1; } };
    prevPreset.onClick = [this] { const int n = presetBox.getNumItems(); presetBox.setSelectedId (((proc.getCurrentProgram() - 1 + n) % n) + 1); };
    nextPreset.onClick = [this] { const int n = presetBox.getNumItems(); presetBox.setSelectedId (((proc.getCurrentProgram() + 1) % n) + 1); };
    root.addAndMakeVisible (presetBox); root.addAndMakeVisible (prevPreset); root.addAndMakeVisible (nextPreset);
    stereoSeg = std::make_unique<Segmented> (s, pid::mono, juce::StringArray { "STEREO", "MONO" }, pk);
    root.addAndMakeVisible (*stereoSeg);
    orderBox = std::make_unique<Combo> (s, pid::order, choices::order); root.addAndMakeVisible (*orderBox);
    widthKnob = std::make_unique<Knob> (s, pid::width, "WIDTH", pk, true);
    inKnob = std::make_unique<Knob> (s, pid::inGain, "IN", pk, true);
    outKnob = std::make_unique<Knob> (s, pid::outGain, "OUT", pk, true);
    mixKnob = std::make_unique<Knob> (s, pid::mix, "MIX", pk, true);
    for (auto* k : { widthKnob.get(), inKnob.get(), outKnob.get(), mixKnob.get() }) root.addAndMakeVisible (k);

    // ---- larp resampler (qaeru mode) + output
    const auto fg = theme::frog;
    larpOn = std::make_unique<Toggle> (s, pid::larpOn, "ON", fg);
    larpDiv = std::make_unique<Segmented> (s, pid::larpDiv, choices::larpDiv, fg);
    larpHw = std::make_unique<Combo> (s, pid::larpHw, choices::larpHw);
    larpGrain = std::make_unique<Knob> (s, pid::larpGrain, "GRAIN", fg, true);
    larpSlop = std::make_unique<Knob> (s, pid::larpSlop, "SLOP", fg, true);
    larpRepeat = std::make_unique<Knob> (s, pid::larpRepeat, "REPEAT", fg, true);
    larpDip = std::make_unique<Knob> (s, pid::larpDeclick, "CHOP DIP", fg, true);
    larpMix = std::make_unique<Knob> (s, pid::larpMix, "MIX", fg, true);
    monoBelow = std::make_unique<Knob> (s, pid::monoBelow, "BASS MONO", lav, true);
    bassKeep = std::make_unique<Knob> (s, pid::bassKeep, "BASS KEEP", lav, true);
    bassLift = std::make_unique<Knob> (s, pid::bassLift, "BASS LIFT", lav, true);
    bassKeep->slider.setTooltip ("Lows below this skip the crush, chops and hiss and come back clean (0 = off)");
    bassLift->slider.setTooltip ("Level of the clean low end that Bass Keep brings back");
    scareBoost = std::make_unique<Toggle> (s, pid::scareBoost, "SCARE BOOST", lav);
    larpHw->box.setTooltip ("Sampler colour: bit depth, sample rate, filters and drive of classic hardware");
    larpGrain->slider.setTooltip ("Micro-chop length inside each slice. Small = grainy 'million chops' chatter; 0 = off");
    monoBelow->slider.setTooltip ("Everything below this frequency is made mono (0 = off). Tight mono low end, wide top");
    scareBoost->b.setTooltip ("When the frog jumps out, slam the output to full scale (0 dBFS max) for 0.3 s");
    for (juce::Component* c : std::initializer_list<juce::Component*> { larpOn.get(), larpDiv.get(), larpHw.get(), larpGrain.get(), larpSlop.get(),
                                larpRepeat.get(), larpDip.get(), larpMix.get(),
                                monoBelow.get(), scareBoost.get(), bassKeep.get(), bassLift.get() })
        root.addAndMakeVisible (c);
    inMeter.get = [this] { return proc.inPeak.load(); };
    outMeter.get = [this] { return proc.outPeak.load(); };
    root.addAndMakeVisible (inMeter); root.addAndMakeVisible (outMeter);

    // ---- warp
    warpMode = std::make_unique<Segmented> (s, pid::warpMode, juce::StringArray { "OFF", "CAPTURE", "SAMPLE" }, lav);
    warpAlgo = std::make_unique<Segmented> (s, pid::warpAlgo, juce::StringArray { "BEATS", "TONES", "TEXTURE", "RE-PITCH", "COMPLEX" }, lav);
    warpSpeed = std::make_unique<Fader> (s, pid::warpSpeed, "SPEED", lav);
    warpSpeed->setPicks ({ { "0.5x (half time)", 0.5f }, { "0.66x", 0.6667f }, { "0.75x (screw)", 0.75f }, { "0.8x", 0.8f },
                           { "0.85x (plaza)", 0.85f }, { "1x", 1.0f }, { "1.25x", 1.25f }, { "1.5x", 1.5f }, { "2x (double)", 2.0f } },
                         [this] (float v) { proc.setParam (pid::warpSpeed, v); });
    warpPitch = std::make_unique<Knob> (s, pid::warpPitch, "PITCH", lav, true);
    warpGrain = std::make_unique<Knob> (s, pid::warpGrain, "GRAIN", lav, true);
    warpFlux = std::make_unique<Knob> (s, pid::warpFlux, "FLUX", lav, true);
    warpEnv = std::make_unique<Knob> (s, pid::warpEnv, "ENVELOPE", lav, true);
    warpBpm = std::make_unique<Knob> (s, pid::warpBpm, "SMP BPM", lav, true);
    warpMix = std::make_unique<Knob> (s, pid::warpMix, "MIX", lav, true);
    warpLoop = std::make_unique<Combo> (s, pid::warpLoop, choices::warpLoop);
    warpPres = std::make_unique<Combo> (s, pid::warpPreserve, choices::warpPres);
    warpLen = std::make_unique<Combo> (s, pid::warpLength, choices::warpLength);
    warpDir = std::make_unique<Combo> (s, pid::warpDir, choices::warpDir);
    warpFreeze = std::make_unique<Toggle> (s, pid::warpFreeze, "FREEZE", lav);
    warpSync = std::make_unique<Toggle> (s, pid::warpSync, "GRID SYNC", lav);
    warpFreeRun = std::make_unique<Toggle> (s, pid::warpFreeRun, "FREE RUN", lav);
    loadBtn.setColour (juce::TextButton::buttonOnColourId, lav);
    loadBtn.onClick = [this] { openSampleChooser(); };
    loadBtn.setTooltip ("Load a WAV / AIFF / FLAC / OGG / MP3 (or drag a file onto the plugin)");
    for (juce::Component* c : std::initializer_list<juce::Component*> { warpMode.get(), warpAlgo.get(), warpSpeed.get(), warpPitch.get(), warpGrain.get(), warpFlux.get(),
                                warpEnv.get(), warpBpm.get(), warpMix.get(), warpLoop.get(), warpPres.get(), warpLen.get(), warpDir.get(),
                                warpFreeze.get(), warpSync.get(), warpFreeRun.get(), &loadBtn, &warpLcd })
        root.addAndMakeVisible (c);
    warpLoop->box.setTooltip ("Beats mode: what happens when a slice ends before the next transient");
    warpLen->box.setTooltip ("Capture window: how often capture re-syncs to the live input (and freeze length)");

    // ---- lofi
    lofiOn = std::make_unique<Toggle> (s, pid::lofiOn, "ON", pk);
    codecType = std::make_unique<Segmented> (s, pid::codecType, juce::StringArray { "CLEAN", "ZOH", "RESAMP", "MP3 '08", "AAC", "REAL", "GSM" }, pk);
    codecSR = std::make_unique<Fader> (s, pid::codecSR, "RATE", pk);
    codecKbps = std::make_unique<Fader> (s, pid::codecKbps, "BITRATE", pk);
    codecBits = std::make_unique<Fader> (s, pid::codecBits, "BITS", pk);
    auto toPicks = [] (const std::vector<std::pair<const char*, float>>& v)
    { std::vector<std::pair<juce::String, float>> o; for (auto& x : v) o.push_back ({ x.first, x.second }); return o; };
    codecSR->setPicks (toPicks (kSampleRatePicks), [this] (float v) { proc.setParam (pid::codecSR, v); });
    codecKbps->setPicks (toPicks (kBitratePicks), [this] (float v) { proc.setParam (pid::codecKbps, v); });
    codecBits->setPicks (toPicks (kBitDepthPicks), [this] (float v) { proc.setParam (pid::codecBits, v); });
    codecSwirl = std::make_unique<Knob> (s, pid::codecSwirl, "SWIRL", pk, true);
    lofiMix = std::make_unique<Knob> (s, pid::lofiMix, "MIX", pk, true);
    codecFrame = std::make_unique<Combo> (s, pid::codecFrame, choices::codecFrame);
    codecStereo = std::make_unique<Combo> (s, pid::codecStereo, choices::codecStereo);
    codecDither = std::make_unique<Toggle> (s, pid::codecDither, "DITHER", pk);
    for (juce::Component* c : std::initializer_list<juce::Component*> { lofiOn.get(), codecType.get(), codecSR.get(), codecKbps.get(), codecBits.get(), codecSwirl.get(),
                                lofiMix.get(), codecFrame.get(), codecStereo.get(), codecDither.get(), &lofiLcd })
        root.addAndMakeVisible (c);
    codecFrame->box.setTooltip ("Codec frame size. Longer = more pre-echo smear; Low Latency = ~3 ms. Latency is reported to FL for compensation.");

    // ---- tape
    hissOn = std::make_unique<Toggle> (s, pid::hissOn, "HISS", mn);
    tapeOn = std::make_unique<Toggle> (s, pid::tapeOn, "TRANSPORT", mn);
    hissType = std::make_unique<Combo> (s, pid::hissType, choices::hissType);
    hissSc = std::make_unique<Combo> (s, pid::hissSc, choices::hissSc);
    hissLevel = std::make_unique<Knob> (s, pid::hissLevel, "LEVEL", mn, true);
    hissTone = std::make_unique<Knob> (s, pid::hissTone, "TONE", mn, true);
    hissScAmt = std::make_unique<Knob> (s, pid::hissScAmt, "SC AMT", mn, true);
    hissScAtk = std::make_unique<Knob> (s, pid::hissScAtk, "SC ATK", mn, true);
    hissScRel = std::make_unique<Knob> (s, pid::hissScRel, "SC REL", mn, true);
    wow = std::make_unique<Knob> (s, pid::wow, "WOW", mn, true);
    flutter = std::make_unique<Knob> (s, pid::flutter, "FLUTTER", mn, true);
    drive = std::make_unique<Knob> (s, pid::tapeDrive, "DRIVE", mn, true);
    azimuth = std::make_unique<Knob> (s, pid::tapeAzimuth, "AZIMUTH", mn, true);
    hfCut = std::make_unique<Knob> (s, pid::tapeHfCut, "HF CUT", mn, true);
    hfRes = std::make_unique<Knob> (s, pid::tapeHfRes, "BUMP", mn, true);
    azimuth->slider.setTooltip ("Tape head misalignment: the left channel lags the right. Phasey, smeared highs");
    hfCut->slider.setTooltip ("Worn heads / dub generations: where the highs fall away");
    hfRes->slider.setTooltip ("Head-bump resonance at the HF cut");
    hissSc->box.setTooltip ("What the hiss level follows. 'Sidechain Bus' uses the plugin's sidechain input (route it in FL's mixer).");
    for (juce::Component* c : std::initializer_list<juce::Component*> { hissOn.get(), tapeOn.get(), hissType.get(), hissSc.get(), hissLevel.get(), hissTone.get(),
                                hissScAmt.get(), hissScAtk.get(), hissScRel.get(), wow.get(), flutter.get(), drive.get(),
                                azimuth.get(), hfCut.get(), hfRes.get() })
        root.addAndMakeVisible (c);

    // ---- dynamics
    transMode = std::make_unique<Segmented> (s, pid::transMode, juce::StringArray { "OFF", "SHARP", "FAT", "BAL", "PUNCH", "SNAP", "SMACK" }, pe);
    transAtk = std::make_unique<Knob> (s, pid::transAttack, "ATTACK", pe, true);
    transSus = std::make_unique<Knob> (s, pid::transSustain, "SUSTAIN", pe, true);
    transFocus = std::make_unique<Knob> (s, pid::transFocus, "FOCUS", pe, true);
    compOn = std::make_unique<Toggle> (s, pid::compOn, "COMPRESSOR", pe);
    compStyle = std::make_unique<Combo> (s, pid::compStyle, choices::compStyle);
    compPresetBtn.setColour (juce::TextButton::buttonOnColourId, pe);
    compPresetBtn.onClick = [this]
    {
        juce::PopupMenu m;
        for (size_t i = 0; i < kCompPresets.size(); ++i) m.addItem ((int) i + 1, kCompPresets[i].name);
        m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&compPresetBtn), [this] (int r)
        {
            if (r <= 0) return;
            const auto& c = kCompPresets[(size_t) r - 1];
            proc.setParam (pid::compOn, 1); proc.setParam (pid::compStyle, c.style); proc.setParam (pid::compThresh, c.thr);
            proc.setParam (pid::compRatio, c.ratio); proc.setParam (pid::compAttack, c.atk); proc.setParam (pid::compRelease, c.rel);
            proc.setParam (pid::compKnee, c.knee); proc.setParam (pid::compMakeup, c.makeup); proc.setParam (pid::compMix, c.mix);
        });
    };
    cThr = std::make_unique<Knob> (s, pid::compThresh, "THRESH", pe, true);
    cRatio = std::make_unique<Knob> (s, pid::compRatio, "RATIO", pe, true);
    cAtk = std::make_unique<Knob> (s, pid::compAttack, "ATTACK", pe, true);
    cRel = std::make_unique<Knob> (s, pid::compRelease, "RELEASE", pe, true);
    cKnee = std::make_unique<Knob> (s, pid::compKnee, "KNEE", pe, true);
    cMake = std::make_unique<Knob> (s, pid::compMakeup, "MAKEUP", pe, true);
    cMix = std::make_unique<Knob> (s, pid::compMix, "MIX", pe, true);
    grMeter.get = [this] { return proc.compGr.load(); }; grMeter.reduction = true;
    for (juce::Component* c : std::initializer_list<juce::Component*> { transMode.get(), transAtk.get(), transSus.get(), transFocus.get(), compOn.get(), compStyle.get(),
                                &compPresetBtn, cThr.get(), cRatio.get(), cAtk.get(), cRel.get(), cKnee.get(), cMake.get(), cMix.get(), &grMeter })
        root.addAndMakeVisible (c);

    // ---- inserts
    for (int i = 0; i < 2; ++i)
    {
        const int sl = i + 1;
        fxOn[i] = std::make_unique<Toggle> (s, pid::fx (sl, "On"), "FX " + juce::String (sl), sk);
        fxType[i] = std::make_unique<Combo> (s, pid::fx (sl, "Type"), choices::fxTypes());
        fxA[i] = std::make_unique<Knob> (s, pid::fx (sl, "A"), "A", sk, true);
        fxB[i] = std::make_unique<Knob> (s, pid::fx (sl, "B"), "B", sk, true);
        fxC[i] = std::make_unique<Knob> (s, pid::fx (sl, "C"), "C", sk, true);
        fxMix[i] = std::make_unique<Knob> (s, pid::fx (sl, "Mix"), "BALANCE", sk, true);
        for (juce::Component* c : std::initializer_list<juce::Component*> { fxOn[i].get(), fxType[i].get(), fxA[i].get(), fxB[i].get(), fxC[i].get(), fxMix[i].get() })
            root.addAndMakeVisible (c);
    }

    root.addChildComponent (scare);
    root.painter = [this] (juce::Graphics& g) { paintChassis (g); };
    root.layout = [this] { layoutRoot(); };
    addAndMakeVisible (root);
    setWantsKeyboardFocus (true);
    addMouseListener (this, true);           // any click focuses us so "qaeru" can be typed
    const float sc = juce::jlimit (0.5f, 2.0f, proc.uiScale.load());   // read before the constrainer can resize us
    setResizable (true, true);
    setResizeLimits (kBaseW / 2, kBaseH / 2, kBaseW * 2, kBaseH * 2);
    getConstrainer()->setFixedAspectRatio ((double) kBaseW / (double) kBaseH);
    setSize (juce::roundToInt (kBaseW * sc), juce::roundToInt (kBaseH * sc));
    sendLookAndFeelChange();                 // make every child rebuild its text boxes with our look
    refreshPresetBox();
    refreshFxLabels();
    startTimerHz (30);
}

ProtofukrEditor::~ProtofukrEditor()
{
    removeMouseListener (this);
    setLookAndFeel (nullptr);
}

void ProtofukrEditor::paintChassis (juce::Graphics& g)
{
    // chassis
    g.setGradientFill (juce::ColourGradient (theme::chassisDark.brighter (0.2f), 0, 0, theme::chassisDark.darker (0.15f), 0, (float) kBaseH, false));
    g.fillAll();
    juce::Random rnd (7);
    for (int y = 0; y < kBaseH; y += 3)
    {
        g.setColour (juce::Colours::white.withAlpha (0.03f + 0.04f * rnd.nextFloat()));
        g.drawHorizontalLine (y, 0.0f, (float) kBaseW);
    }
    // screws
    for (auto pt : { juce::Point<float> (9, 9), juce::Point<float> ((float) kBaseW - 9, 9),
                     juce::Point<float> (9, (float) kBaseH - 9), juce::Point<float> ((float) kBaseW - 9, (float) kBaseH - 9) })
    {
        auto r = juce::Rectangle<float> (9, 9).withCentre (pt);
        g.setGradientFill (juce::ColourGradient (theme::chassisLight, r.getX(), r.getY(), theme::groove, r.getRight(), r.getBottom(), false));
        g.fillEllipse (r);
        g.setColour (theme::groove); g.drawLine (r.getX() + 2, r.getCentreY(), r.getRight() - 2, r.getCentreY(), 1.2f);
    }

    // mascot: a small, perfectly harmless frog
    {
        const juce::Point<float> c (42, 40);
        auto head = juce::Rectangle<float> (46, 32).withCentre (c.translated (0, 4));
        theme::glossFill (g, head, theme::mint, 16.0f);
        for (int side = -1; side <= 1; side += 2)
        {
            auto e = juce::Rectangle<float> (17, 17).withCentre (c.translated ((float) side * 12.0f, -10.0f));
            theme::glossFill (g, e, theme::mint, 8.5f);
            g.setColour (theme::ink); g.fillEllipse (e.reduced (4.5f));
            g.setColour (juce::Colours::white); g.fillEllipse (juce::Rectangle<float> (3, 3).withCentre (e.getCentre().translated (-1.5f, -1.5f)));
            g.setColour (theme::pink.withAlpha (0.9f));
            g.fillEllipse (juce::Rectangle<float> (8, 4).withCentre (c.translated ((float) side * 15.0f, 8.0f)));
        }
        juce::Path smile; smile.addCentredArc (c.x, c.y + 4.0f, 7.0f, 4.0f, 0.0f, 2.0f, 4.28f, true);
        g.setColour (theme::ink); g.strokePath (smile, juce::PathStrokeType (1.6f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
    }

    // logo: glossy pink outlined word mark
    {
        juce::GlyphArrangement ga;
        ga.addLineOfText (theme::header (34.0f), "protofukr", 76.0f, 50.0f);
        juce::Path text; ga.createPath (text);
        g.setColour (theme::ink);
        g.strokePath (text, juce::PathStrokeType (5.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded), juce::AffineTransform::translation (0, 2));
        g.strokePath (text, juce::PathStrokeType (5.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        auto b = text.getBounds();
        juce::ColourGradient grad (juce::Colours::white, 0, b.getY(), theme::hot, 0, b.getBottom(), false);
        grad.addColour (0.45, theme::pink);
        g.setGradientFill (grad);
        g.fillPath (text);
        g.setColour (juce::Colours::white.withAlpha (0.55f));
        g.saveState(); g.reduceClipRegion (b.withHeight (b.getHeight() * 0.42f).toNearestInt()); g.fillPath (text); g.restoreState();
        g.setFont (theme::lcd (16.0f)); g.setColour (theme::ink.withAlpha (0.75f));
        g.drawText ("v1.0  lofi / warp / tape", juce::Rectangle<float> (78.0f, 54.0f, 200.0f, 16.0f), juce::Justification::left);
    }
}

void ProtofukrEditor::resized()
{
    const float sc = (float) getWidth() / (float) kBaseW;
    root.setTransform (juce::AffineTransform::scale (sc));
    root.setBounds (0, 0, kBaseW, kBaseH);
    proc.uiScale = sc;
}

void ProtofukrEditor::layoutRoot()
{
    // ---- top bar
    prevPreset.setBounds (282, 24, 26, 26);
    presetBox.setBounds (310, 24, 250, 26);
    nextPreset.setBounds (562, 24, 26, 26);
    stereoSeg->setBounds (604, 24, 130, 26);
    orderBox->setBounds (744, 24, 118, 26);
    int kx = 928;
    for (auto* k : { inKnob.get(), outKnob.get(), mixKnob.get() }) { k->setBounds (kx, 4, 58, 72); kx += 58; }
    inMeter.setBounds (1106, 10, 9, 62);
    outMeter.setBounds (1119, 10, 9, 62);

    // ---- warp
    warpPanel.setBounds (10, 84, 610, 318);
    {
        auto c = warpPanel.content().translated (warpPanel.getX(), warpPanel.getY());
        auto row = c.removeFromTop (26);
        warpMode->setBounds (row.removeFromLeft (200));
        row.removeFromLeft (10);
        warpAlgo->setBounds (row);
        c.removeFromTop (10);
        warpSpeed->setBounds (c.removeFromLeft (70));
        c.removeFromLeft (10);
        auto right = c.removeFromRight (182);
        c.removeFromRight (10);
        warpLcd.setBounds (c.removeFromTop (128));
        c.removeFromTop (8);
        const int kw = c.getWidth() / 6;
        for (auto* k : { warpPitch.get(), warpGrain.get(), warpFlux.get(), warpEnv.get(), warpBpm.get(), warpMix.get() }) k->setBounds (c.removeFromLeft (kw).withHeight (84));
        for (auto* cb : { warpLoop.get(), warpPres.get(), warpLen.get(), warpDir.get() }) { cb->setBounds (right.removeFromTop (24)); right.removeFromTop (6); }
        auto tr = right.removeFromTop (22);
        warpFreeze->setBounds (tr.removeFromLeft (84)); warpSync->setBounds (tr);
        right.removeFromTop (4);
        warpFreeRun->setBounds (right.removeFromTop (22));
        right.removeFromTop (8);
        loadBtn.setBounds (right.removeFromTop (28));
    }

    // ---- lofi
    lofiPanel.setBounds (630, 84, 500, 318);
    {
        lofiOn->setBounds (lofiPanel.headerRight (52).translated (lofiPanel.getX(), lofiPanel.getY()));
        auto c = lofiPanel.content().translated (lofiPanel.getX(), lofiPanel.getY());
        codecType->setBounds (c.removeFromTop (26));
        c.removeFromTop (10);
        for (auto* f : { codecSR.get(), codecKbps.get(), codecBits.get() }) { f->setBounds (c.removeFromLeft (74)); c.removeFromLeft (4); }
        c.removeFromLeft (8);
        lofiLcd.setBounds (c.removeFromTop (128));
        c.removeFromTop (8);
        codecSwirl->setBounds (c.removeFromLeft (60).withHeight (84));
        lofiMix->setBounds (c.removeFromLeft (60).withHeight (84));
        c.removeFromLeft (8);
        codecFrame->setBounds (c.removeFromTop (24)); c.removeFromTop (6);
        codecStereo->setBounds (c.removeFromTop (24)); c.removeFromTop (6);
        codecDither->setBounds (c.removeFromTop (22));
    }

    // ---- tape
    tapePanel.setBounds (10, 410, 340, 324);
    {
        auto c = tapePanel.content().translated (tapePanel.getX(), tapePanel.getY());
        auto r1 = c.removeFromTop (24);
        hissOn->setBounds (r1.removeFromLeft (70)); hissType->setBounds (r1);
        c.removeFromTop (6);
        auto r2 = c.removeFromTop (24);
        r2.removeFromLeft (70); hissSc->setBounds (r2);
        c.removeFromTop (6);
        auto k1 = c.removeFromTop (86);
        const int kw = k1.getWidth() / 5;
        for (auto* k : { hissLevel.get(), hissTone.get(), hissScAmt.get(), hissScAtk.get(), hissScRel.get() }) k->setBounds (k1.removeFromLeft (kw));
        c.removeFromTop (8);
        tapeOn->setBounds (c.removeFromTop (22).withWidth (140));
        c.removeFromTop (4);
        auto k2 = c.removeFromTop (86);
        const int kw2 = k2.getWidth() / 6;
        for (auto* k : { wow.get(), flutter.get(), drive.get(), azimuth.get(), hfCut.get(), hfRes.get() }) k->setBounds (k2.removeFromLeft (kw2));
    }

    // ---- dynamics
    dynPanel.setBounds (360, 410, 400, 324);
    {
        auto c = dynPanel.content().translated (dynPanel.getX(), dynPanel.getY());
        transMode->setBounds (c.removeFromTop (26));
        c.removeFromTop (8);
        auto r = c.removeFromTop (90);
        for (auto* k : { transAtk.get(), transSus.get(), transFocus.get() }) k->setBounds (r.removeFromLeft (62));
        r.removeFromLeft (14);
        compOn->setBounds (r.removeFromTop (22)); r.removeFromTop (6);
        compStyle->setBounds (r.removeFromTop (24)); r.removeFromTop (6);
        compPresetBtn.setBounds (r.removeFromTop (26));
        c.removeFromTop (14);
        auto k = c.removeFromTop (90);
        grMeter.setBounds (k.removeFromRight (12).reduced (0, 6));
        k.removeFromRight (4);
        const int kw = k.getWidth() / 7;
        for (auto* kn : { cThr.get(), cRatio.get(), cAtk.get(), cRel.get(), cKnee.get(), cMake.get(), cMix.get() }) kn->setBounds (k.removeFromLeft (kw));
    }

    // ---- inserts
    fxPanel.setBounds (770, 410, 360, 324);
    {
        auto c = fxPanel.content().translated (fxPanel.getX(), fxPanel.getY());
        for (int i = 0; i < 2; ++i)
        {
            auto slot = c.removeFromTop (134);
            auto r = slot.removeFromTop (24);
            fxOn[i]->setBounds (r.removeFromLeft (70)); fxType[i]->setBounds (r);
            slot.removeFromTop (6);
            const int kw = slot.getWidth() / 4;
            for (auto* k : { fxA[i].get(), fxB[i].get(), fxC[i].get(), fxMix[i].get() }) k->setBounds (slot.removeFromLeft (kw).withHeight (92));
            c.removeFromTop (8);
        }
    }

    // ---- larp resampler (qaeru mode)
    larpPanel.setBounds (10, 742, 830, 172);
    {
        larpOn->setBounds (larpPanel.headerRight (52).translated (larpPanel.getX(), larpPanel.getY()));
        auto c = larpPanel.content().translated (larpPanel.getX(), larpPanel.getY());
        auto r1 = c.removeFromTop (26);
        larpHw->setBounds (r1.removeFromRight (200));
        r1.removeFromRight (10);
        larpDiv->setBounds (r1);
        c.removeFromTop (8);
        const int kw = c.getWidth() / 5;
        for (auto* k : { larpGrain.get(), larpSlop.get(), larpRepeat.get(), larpDip.get(), larpMix.get() })
            k->setBounds (c.removeFromLeft (kw).withHeight (88));
    }
    outPanel.setBounds (850, 742, 280, 172);
    {
        auto c = outPanel.content().translated (outPanel.getX(), outPanel.getY());
        scareBoost->setBounds (c.removeFromTop (26).reduced (4, 2));
        c.removeFromTop (8);
        const int kw = c.getWidth() / 4;
        for (auto* k : { widthKnob.get(), monoBelow.get(), bassKeep.get(), bassLift.get() }) k->setBounds (c.removeFromLeft (kw).withHeight (88));
    }

    scare.setBounds (root.getLocalBounds());
}

void ProtofukrEditor::refreshPresetBox()
{
    const int cur = proc.getCurrentProgram();
    if (cur != shownProgram) { shownProgram = cur; presetBox.setSelectedId (cur + 1, juce::dontSendNotification); }
}

void ProtofukrEditor::refreshFxLabels()
{
    for (int i = 0; i < 2; ++i)
    {
        const int t = (int) proc.apvts.getRawParameterValue (pid::fx (i + 1, "Type"))->load();
        if (t == shownFxType[i]) continue;
        shownFxType[i] = t;
        const char *a, *b, *c; pf::InsertFX::labels (t, a, b, c);
        fxA[i]->setCaption (a); fxB[i]->setCaption (b); fxC[i]->setCaption (c);
    }
}

void ProtofukrEditor::timerCallback()
{
    refreshPresetBox();
    refreshFxLabels();
    const auto name = proc.getSampleName();
    if (name != warpLcd.sampleName) { warpLcd.sampleName = name; warpLcd.peaks = proc.getSamplePeaks(); }
    warpLcd.repaint(); lofiLcd.repaint(); inMeter.repaint(); outMeter.repaint(); grMeter.repaint();
}

bool ProtofukrEditor::keyPressed (const juce::KeyPress& k)
{
    const auto ch = k.getTextCharacter();
    if (! juce::CharacterFunctions::isLetter (ch)) return false;
    typed += juce::String::charToString (juce::CharacterFunctions::toLowerCase (ch));
    if (typed.length() > 8) typed = typed.getLastCharacters (8);
    if (typed.endsWith ("qaeru")) { typed.clear(); triggerScare(); return true; }
    return false;
}

void ProtofukrEditor::mouseDown (const juce::MouseEvent& e)
{
    grabKeyboardFocus();
    // we listen to our own clicks and our children's, so ignore the duplicate copy of one click
    if (e.eventTime == lastClickTime) return;
    lastClickTime = e.eventTime;
    const auto pos = e.getEventRelativeTo (&root).position;
    if (! kFrogArea.contains (pos)) { frogClicks = 0; return; }
    const auto now = juce::Time::getMillisecondCounter();
    frogClicks = (now - lastFrogClick < 700) ? frogClicks + 1 : 1;
    lastFrogClick = now;
    if (frogClicks >= 3) { frogClicks = 0; triggerScare(); }
}

void ProtofukrEditor::triggerScare()
{
    if (scare.isRunning()) return;
    auto img = root.createComponentSnapshot (root.getLocalBounds(), true, 1.0f);
    proc.triggerScareBoost (0.95);    // lands when the frog lunges
    scare.start (img);
}

void ProtofukrEditor::openSampleChooser()
{
    chooser = std::make_unique<juce::FileChooser> ("Load a sample to warp", juce::File(), "*.wav;*.aif;*.aiff;*.flac;*.ogg;*.mp3");
    chooser->launchAsync (juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles, [this] (const juce::FileChooser& fc)
    {
        const auto f = fc.getResult();
        if (f.existsAsFile() && proc.loadSample (f)) proc.setParam (pid::warpMode, 2.0f);
    });
}

void ProtofukrEditor::filesDropped (const juce::StringArray& files, int, int)
{
    for (auto& path : files)
        if (proc.loadSample (juce::File (path))) { proc.setParam (pid::warpMode, 2.0f); break; }
}

juce::AudioProcessorEditor* ProtofukrProcessor::createEditor() { return new ProtofukrEditor (*this); }
