#pragma once
// protofukr — LOFI section: sample-rate / bit-depth reduction and lossy-codec emulation.
//
//  Types
//   Clean      : bypass (only bit depth applies)
//   ZOH Crush  : sample & hold at target rate, no filtering (aliasing, "Ableton Redux / Audacity no-filter")
//   Resample   : band-limited down/up resample (dull, smooth — classic converter sound)
//   MP3 '08    : MDCT coder modelled on low-bitrate MP3 / 2008 YouTube FLV audio (swirly highs, pre-echo, holes)
//   AAC        : MDCT coder modelled on the fmt=18 era AAC tier (smoother, wider band)
//   Real '99   : coarse-band streaming codec (metallic, narrow, "RealPlayer" warble)
//   GSM Phone  : 300–3400 Hz, short frames, mu-law crunch
//
// MDCT types run at host rate; sample-rate reduction is applied as codec bandwidth exactly as an
// encoder's lowpass + reduced Nyquist would, so no resampling latency is added. Latency == hop size M.
#include "Common.h"
#include <juce_dsp/juce_dsp.h>
#include <array>
#include <complex>
#include <memory>

namespace pf
{
class LofiCodec
{
public:
    enum Type { Clean = 0, ZOH, Resample, MP3, AAC, Real, GSM, NumTypes };
    enum Frame { FrameAuto = 0, FrameLowLat, FrameShort, FrameLong, FrameHuge };
    enum StereoMode { Stereo = 0, Joint, Mono };

    struct Params
    {
        int   type = Clean;
        float targetSR = 44100.0f;
        float kbps = 128.0f;
        float bits = 24.0f;
        int   frame = FrameAuto;
        int   stereo = Stereo;
        float swirl = 0.0f;      // 0..1
        bool  dither = false;
        float mix = 1.0f;        // section dry/wet
    };

    static constexpr int kMaxM = 2048;

    void prepare (double sampleRate)
    {
        sr = sampleRate;
        for (int o = 0; o < 6; ++o)                    // N = 256 .. 8192  (M = 128 .. 4096)
            ffts[(size_t) o] = std::make_unique<juce::dsp::FFT> (8 + o);
        for (auto& c : ch)
        {
            c.inHist.assign (2 * kMaxM, 0.0f);
            c.outFifo.assign (kMaxM, 0.0f);
            c.tail.assign (kMaxM, 0.0f);
            c.spec.assign (kMaxM, 0.0f);
            c.pow34.assign (kMaxM, 0.0f);
            c.dry.prepare (2 * kMaxM + 8);
        }
        work.assign (2 * kMaxM * 2, {});
        work2.assign (2 * kMaxM * 2, {});
        window.assign (2 * kMaxM, 0.0f);
        for (int i = 0; i < 4; ++i) { pre[0][i].reset(); pre[1][i].reset(); post[0][i].reset(); post[1][i].reset(); }
        gsmHP[0].reset(); gsmHP[1].reset();
        currentM = 0;
        reset();
    }

    void reset()
    {
        for (auto& c : ch)
        {
            std::fill (c.inHist.begin(), c.inHist.end(), 0.0f);
            std::fill (c.outFifo.begin(), c.outFifo.end(), 0.0f);
            std::fill (c.tail.begin(), c.tail.end(), 0.0f);
            c.dry.clear();
            c.held = 0; c.phase = 1.0f;
        }
        fifoPos = 0;
    }

    // Hop size (and therefore latency) a given type/frame/rate combination will use.
    int hopFor (int type, int frame, float targetSR) const
    {
        if (type < MP3) return 0;
        switch (frame)
        {
            case FrameLowLat: return 128;
            case FrameShort:  return 256;
            case FrameLong:   return 1024;
            case FrameHuge:   return 2048;
            default: break;
        }
        const float codecSR = clampf (targetSR, 4000.0f, (float) sr);
        float nominal = 576.0f;                    // MP3 granule
        if (type == AAC)  nominal = 1024.0f;
        if (type == Real) nominal = 512.0f;
        if (type == GSM)  nominal = 160.0f * 2.0f; // 20 ms frames, MDCT hop ~ half a frame window
        if (type == GSM)  return nearestPow2 (clampf (0.02f * (float) sr, 128.0f, 2048.0f));
        const float m = nominal * (float) sr / codecSR;
        return nearestPow2 (clampf (m, 128.0f, (float) kMaxM));
    }

    // MDCT overlap-add needs a full frame (2 hops) before a sample is complete.
    int latencyFor (const Params& p) const { return 2 * hopFor (p.type, p.frame, p.targetSR); }

    void process (float* L, float* R, int n, const Params& p)
    {
        const bool stereoIn = (R != nullptr);
        if (p.type == Clean)
        {
            applyBits (L, R, n, p);
            currentM = 0;
            return;
        }
        if (p.type == ZOH || p.type == Resample)
        {
            currentM = 0;
            processSampleRate (L, n, p, 0);
            if (stereoIn) processSampleRate (R, n, p, 1);
            applyBits (L, R, n, p);
            return;
        }

        // ---- MDCT codecs -------------------------------------------------------------
        const int M = hopFor (p.type, p.frame, p.targetSR);
        if (M != currentM) { reconfigure (M); }

        if (p.type == GSM)
        {
            // Telephone band + 8 kHz-ish reduction before coding
            gsmHP[0].set (Biquad::HP, sr, 300.0f, 0.707f); gsmHP[1].set (Biquad::HP, sr, 300.0f, 0.707f);
            for (int i = 0; i < n; ++i) { L[i] = gsmHP[0].process (L[i]); if (stereoIn) R[i] = gsmHP[1].process (R[i]); }
        }

        float* chans[2] = { L, stereoIn ? R : L };
        const int numCh = stereoIn ? 2 : 1;
        const float wet = p.mix, dryG = 1.0f - p.mix;

        for (int i = 0; i < n; ++i)
        {
            for (int c = 0; c < numCh; ++c)
            {
                auto& s = ch[(size_t) c];
                const float x = chans[c][i];
                s.dry.push (x);
                s.inHist[(size_t) (M + fifoPos)] = x;
                const float y = s.outFifo[(size_t) fifoPos];
                chans[c][i] = wet * y + (dryG > 0.0f ? dryG * s.dry.readInt ((uint32_t) (2 * M) + 1) : 0.0f);
            }
            if (++fifoPos >= M)
            {
                fifoPos = 0;
                processFrame (M, numCh, p);
            }
        }

        if (p.type == GSM)
        {
            // mu-law crunch on top of the codec
            const float mu = 255.0f;
            const float levels = std::pow (2.0f, clampf (std::min (p.bits, 8.0f), 1.0f, 24.0f) - 1.0f);
            for (int c = 0; c < numCh; ++c)
                for (int i = 0; i < n; ++i)
                {
                    const float x = clampf (chans[c][i], -1.0f, 1.0f);
                    float y = std::copysign (std::log1p (mu * std::abs (x)) / std::log1p (mu), x);
                    y = std::round (y * levels) / levels;
                    chans[c][i] = std::copysign ((std::pow (1.0f + mu, std::abs (y)) - 1.0f) / mu, y);
                }
        }
        else
        {
            applyBits (L, R, n, p);
        }
    }

    int currentHop() const { return currentM; }
    int currentLatency() const { return 2 * currentM; }
    float currentBandwidthHz() const { return lastBandwidth; }

private:
    struct Chan
    {
        std::vector<float> inHist, outFifo, tail, spec, pow34;
        DelayLine dry;
        float held = 0, phase = 1.0f;
    };

    static int nearestPow2 (float v)
    {
        int p = 128;
        while (p * 2 <= kMaxM && std::abs ((float) (p * 2) - v) < std::abs ((float) p - v)) p *= 2;
        return p;
    }

    void reconfigure (int M)
    {
        currentM = M;
        const int N = 2 * M;
        for (int i = 0; i < N; ++i) window[(size_t) i] = std::sin (kPi * ((float) i + 0.5f) / (float) N);
        for (auto& c : ch)
        {
            std::fill (c.inHist.begin(), c.inHist.end(), 0.0f);
            std::fill (c.outFifo.begin(), c.outFifo.end(), 0.0f);
            std::fill (c.tail.begin(), c.tail.end(), 0.0f);
        }
        fifoPos = 0;
        // Bark-ish scalefactor bands mapped onto this M
        static const float edges[] = { 0, 100, 200, 300, 400, 510, 630, 770, 920, 1080, 1270, 1480, 1720, 2000, 2320,
                                       2700, 3150, 3700, 4400, 5300, 6400, 7700, 9500, 12000, 15500, 20500, 1.0e9f };
        numBands = 0;
        const float binHz = (float) sr / (float) N;
        int last = 0;
        for (size_t e = 1; e < sizeof (edges) / sizeof (edges[0]) && last < M; ++e)
        {
            int hi = std::min (M, std::max (last + 1, (int) std::round (edges[e] / binHz)));
            if (e + 1 == sizeof (edges) / sizeof (edges[0])) hi = M;
            bandLo[numBands] = last; bandHi[numBands] = hi; ++numBands;
            last = hi;
        }
        // absolute threshold (Terhardt), referenced so 0 dBFS ~ 96 dB SPL
        for (int b = 0; b < numBands; ++b)
        {
            const float f = std::max (40.0f, 0.5f * (float) (bandLo[b] + bandHi[b]) * binHz) * 0.001f;
            const float athDb = 3.64f * std::pow (f, -0.8f) - 6.5f * std::exp (-0.6f * (f - 3.3f) * (f - 3.3f)) + 1.0e-3f * f * f * f * f;
            athPow[b] = std::pow (10.0f, (athDb - 96.0f) / 10.0f);
        }
    }

    // Lame-like lowpass vs per-channel bitrate
    static float lowpassForKbps (float k)
    {
        static const float kb[] = { 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 1000 };
        static const float hz[] = { 2000, 3700, 3900, 5500, 7000, 7500, 10000, 11000, 13500, 15100, 15600, 17000, 17500, 18600, 19400, 19700, 20500, 22000 };
        if (k <= kb[0]) return hz[0] * k / kb[0];
        for (int i = 1; i < 18; ++i)
            if (k <= kb[i]) { const float t = (k - kb[i - 1]) / (kb[i] - kb[i - 1]); return hz[i - 1] + t * (hz[i] - hz[i - 1]); }
        return 22000.0f;
    }

    void mdct (const float* x, float* out, int M)
    {
        const int N = 2 * M;
        const float n0 = 0.5f + 0.5f * (float) M;
        for (int n = 0; n < N; ++n)
        {
            const float a = -kPi * (float) n / (float) N;
            work[(size_t) n] = std::complex<float> (x[n] * window[(size_t) n] * std::cos (a), x[n] * window[(size_t) n] * std::sin (a));
        }
        fftFor (N).perform (work.data(), work2.data(), false);
        for (int k = 0; k < M; ++k)
        {
            const float a = -kPi * n0 * ((float) k + 0.5f) / (float) M;
            out[k] = work2[(size_t) k].real() * std::cos (a) - work2[(size_t) k].imag() * std::sin (a);
        }
    }

    // returns windowed time-domain block of length N (scaled for TDAC)
    void imdct (const float* X, float* y, int M)
    {
        const int N = 2 * M;
        const float n0 = 0.5f + 0.5f * (float) M;
        for (int k = 0; k < N; ++k)
        {
            if (k < M)
            {
                const float a = kPi * n0 * (float) k / (float) M;
                work[(size_t) k] = std::complex<float> (X[k] * std::cos (a), X[k] * std::sin (a));
            }
            else work[(size_t) k] = {};
        }
        fftFor (N).perform (work.data(), work2.data(), true);   // juce inverse is scaled by 1/N
        const float scale = 4.0f;                                 // (N * 2/M) / N with 1/N already applied → 2*N/M/N*... calibrated: 4
        for (int n = 0; n < N; ++n)
        {
            const float a = kPi * ((float) n + n0) / (float) N;
            const auto c = work2[(size_t) n];
            y[n] = scale * (c.real() * std::cos (a) - c.imag() * std::sin (a)) * window[(size_t) n];
        }
    }

    juce::dsp::FFT& fftFor (int N)
    {
        int o = 0; while ((256 << o) < N) ++o;
        return *ffts[(size_t) o];
    }

    void processFrame (int M, int numCh, const Params& p)
    {
        const int N = 2 * M;
        float* specs[2] = { ch[0].spec.data(), ch[1].spec.data() };

        for (int c = 0; c < numCh; ++c)
            mdct (ch[(size_t) c].inHist.data(), specs[c], M);

        // stereo handling
        bool ms = false;
        if (numCh == 2 && p.stereo != Stereo)
        {
            for (int k = 0; k < M; ++k)
            {
                const float l = specs[0][k], r = specs[1][k];
                specs[0][k] = 0.5f * (l + r);
                specs[1][k] = (p.stereo == Mono) ? 0.0f : 0.5f * (l - r);
            }
            ms = true;
        }

        quantize (M, numCh, p, ms);

        if (ms)
            for (int k = 0; k < M; ++k)
            {
                const float m = specs[0][k], s = specs[1][k];
                specs[0][k] = m + s; specs[1][k] = m - s;
            }

        float y[2 * kMaxM];
        for (int c = 0; c < numCh; ++c)
        {
            auto& s = ch[(size_t) c];
            imdct (specs[c], y, M);
            for (int i = 0; i < M; ++i)
            {
                s.outFifo[(size_t) i] = sanitize (s.tail[(size_t) i] + y[i]);
                s.tail[(size_t) i] = y[i + M];
            }
            // shift input history
            std::copy (s.inHist.begin() + M, s.inHist.begin() + N, s.inHist.begin());
        }
    }

    void quantize (int M, int numCh, const Params& p, bool ms)
    {
        const int type = p.type;
        const float binHz = (float) sr / (float) (2 * M);

        // ---- bandwidth: reduced Nyquist + encoder lowpass ----
        const float nyq = 0.5f * clampf (p.targetSR, 1000.0f, (float) sr);
        float perCh = p.kbps / (numCh == 2 ? (p.stereo == Stereo ? 2.0f : 1.6f) : 1.0f);
        if (p.stereo == Mono) perCh = p.kbps;
        float lp = lowpassForKbps (perCh);
        if (type == AAC)  lp = lowpassForKbps (perCh * 1.45f);
        if (type == Real) lp = lowpassForKbps (perCh * 0.7f) * 0.85f;
        if (type == GSM)  lp = 3400.0f;
        const float bw = std::min (nyq * 0.97f, lp);
        lastBandwidth = bw;
        const int kMax = std::min (M, (int) (bw / binHz));

        // ---- bit budget for this frame ----
        const float frameSec = (float) M / (float) sr;
        float budget = p.kbps * 1000.0f * frameSec * 0.9f;            // ~10% headers/side info
        if (type == Real) budget *= 0.8f;

        // ---- per-band masking thresholds ----
        const float smrDb = (type == AAC ? 18.0f : (type == Real ? 9.0f : 13.0f));
        const float smr = std::pow (10.0f, -smrDb / 10.0f);
        const int bandStep = (type == Real || type == GSM) ? 3 : 1;     // coarse bands → metallic
        const float swirl = clampf (p.swirl, 0.0f, 1.0f);

        float bandE[2][32] {}, thr[2][32] {};
        for (int c = 0; c < numCh; ++c)
        {
            float* X = ch[(size_t) c].spec.data();
            float* P = ch[(size_t) c].pow34.data();
            for (int k = 0; k < M; ++k) { if (k >= kMax) X[k] = 0.0f; P[k] = std::pow (std::abs (X[k]), 0.75f); }
            for (int b = 0; b < numBands; b += bandStep)
            {
                const int lo = bandLo[b], hi = bandHi[std::min (numBands - 1, b + bandStep - 1)];
                float e = 0; for (int k = lo; k < hi; ++k) e += X[k] * X[k];
                for (int bb = b; bb < std::min (numBands, b + bandStep); ++bb) bandE[c][bb] = e / (float) std::max (1, hi - lo);
            }
            for (int b = 0; b < numBands; ++b)
            {
                float m = 0;
                for (int j = 0; j < numBands; ++j)
                {
                    const int d = j - b;
                    const float spreadDb = d < 0 ? 27.0f * (float) d : -15.0f * (float) d;   // steeper downward
                    m = std::max (m, bandE[c][j] * std::pow (10.0f, spreadDb / 10.0f));
                }
                float t = std::max (m * smr, athPow[b] * (float) (2 * M));
                if (ms && c == 1) t *= 2.0f;                                     // side gets less care
                if (swirl > 0.0f) t *= 1.0f + swirl * 6.0f * rng.uni();         // time-variant allocation = swirl
                thr[c][b] = t;
            }
        }

        // ---- rate loop: find global gain so bits fit budget ----
        const float roundOff = (type == Real ? 0.25f : 0.4054f) - 0.25f * swirl;
        auto costFor = [&] (float logG) -> float
        {
            float bits = 0;
            const float g = std::exp2 (logG);
            for (int c = 0; c < numCh; ++c)
            {
                const float* P = ch[(size_t) c].pow34.data();
                for (int b = 0; b < numBands; ++b)
                {
                    const int lo = bandLo[b], hi = std::min (bandHi[b], kMax);
                    if (lo >= hi) continue;
                    const float step = g * std::sqrt (thr[c][b]);
                    const float inv = 1.0f / std::pow (std::max (step, 1.0e-12f), 0.75f);
                    float bb = 0; bool any = false;
                    for (int k = lo; k < hi; ++k)
                    {
                        const float q = std::floor (P[k] * inv + roundOff);
                        if (q <= 0.0f) bb += 0.45f;
                        else { bb += 1.5f + 1.7f * std::log2 (q); any = true; }
                    }
                    bits += any ? bb + 4.0f : 1.0f;
                }
            }
            return bits;
        };

        float lo = -12.0f, hi = 24.0f;
        if (costFor (lo) <= budget) hi = lo;
        else
            for (int it = 0; it < 12; ++it)
            {
                const float mid = 0.5f * (lo + hi);
                if (costFor (mid) > budget) lo = mid; else hi = mid;
            }
        const float g = std::exp2 (hi);

        // ---- quantize / dequantize in place ----
        for (int c = 0; c < numCh; ++c)
        {
            float* X = ch[(size_t) c].spec.data();
            const float* P = ch[(size_t) c].pow34.data();
            for (int b = 0; b < numBands; ++b)
            {
                const int lo2 = bandLo[b], hi2 = bandHi[b];
                const float step = g * std::sqrt (thr[c][b]);
                const float inv = 1.0f / std::pow (std::max (step, 1.0e-12f), 0.75f);
                for (int k = lo2; k < hi2; ++k)
                {
                    if (k >= kMax) { X[k] = 0.0f; continue; }
                    const float q = std::floor (P[k] * inv + roundOff);
                    X[k] = q <= 0.0f ? 0.0f : std::copysign (std::pow (q, 4.0f / 3.0f) * step, X[k]);
                }
            }
        }
    }

    void processSampleRate (float* x, int n, const Params& p, int c)
    {
        auto& s = ch[(size_t) c];
        const float target = clampf (p.targetSR, 200.0f, (float) sr);
        if (target >= (float) sr * 0.999f) return;
        const float inc = target / (float) sr;
        if (p.type == Resample)
        {
            static const float qs[4] = { 0.5098f, 0.6013f, 0.9000f, 2.5629f };   // 8th-order Butterworth
            const float fc = target * 0.45f;
            for (int k = 0; k < 4; ++k) { pre[c][k].set (Biquad::LP, sr, fc, qs[k]); post[c][k].set (Biquad::LP, sr, fc, qs[k]); }
        }
        for (int i = 0; i < n; ++i)
        {
            float v = x[i];
            if (p.type == Resample) for (int k = 0; k < 4; ++k) v = pre[c][k].process (v);
            s.phase += inc;
            if (s.phase >= 1.0f) { s.phase -= 1.0f; s.held = v; }
            v = s.held;
            if (p.type == Resample) for (int k = 0; k < 4; ++k) v = post[c][k].process (v);
            x[i] = p.mix * v + (1.0f - p.mix) * x[i];
        }
    }

    void applyBits (float* L, float* R, int n, const Params& p)
    {
        if (p.bits >= 23.99f) return;
        const float levels = std::pow (2.0f, clampf (p.bits, 1.0f, 24.0f) - 1.0f);
        const float inv = 1.0f / levels;
        auto q = [&] (float x)
        {
            if (p.dither) x += (rng.uni() - rng.uni()) * inv;
            return clampf (std::round (x * levels) * inv, -1.0f, 1.0f);
        };
        for (int i = 0; i < n; ++i)
        {
            L[i] = p.mix * q (L[i]) + (1.0f - p.mix) * L[i];
            if (R) R[i] = p.mix * q (R[i]) + (1.0f - p.mix) * R[i];
        }
    }

    double sr = 44100.0;
    std::array<std::unique_ptr<juce::dsp::FFT>, 6> ffts;
    std::array<Chan, 2> ch;
    std::vector<std::complex<float>> work, work2;
    std::vector<float> window;
    Biquad pre[2][4], post[2][4], gsmHP[2];
    int currentM = 0, fifoPos = 0;
    int numBands = 0, bandLo[32] {}, bandHi[32] {};
    float athPow[32] {};
    float lastBandwidth = 22050.0f;
    Rng rng { 0xC0DECu };
};
} // namespace pf
