#pragma once
// protofukr — LARP RESAMPLER (Qaeru Mode)
// Makes audio sound like it was chopped into many slices on a hardware sampler and pieced back
// together: grid slices (1/1 … 1/64, triplets), micro-grain re-chopping with tiny dips and position
// slop, a per-slice time "smear" (playback lags then catches up — a pitch wobble without real
// pitch shifting, like Gross Beat's time curves), slice repeats, sampler colour (MPC60 / MPC3000 /
// SP-1200 / S950 / MPC2000XL-style / dusty), plus a metallic comb "ring" for that flute shimmer.
// Everything reads from the past only, so it adds no latency.
#include "Common.h"

namespace pf
{
class LarpResampler
{
public:
    enum Hardware { HwClean = 0, HwMPC60, HwMPC3000, HwSP1200, HwS950, HwMPC2000, HwDusty, NumHw };
    static constexpr int kNumDivs = 9;
    static double divisionBeats (int d)
    {
        static const double v[kNumDivs] = { 4.0, 2.0, 1.0, 0.5, 0.25, 0.125, 0.0625, 1.0 / 3.0, 1.0 / 6.0 };
        return v[juce_clamp (d)];
    }

    struct Params
    {
        bool on = false; int division = 4; int hardware = HwMPC60;
        float grainMs = 30.0f;   // 0 = no micro-chops
        float slop = 0.3f, smear = 0.3f, repeat = 0.15f, declick = 0.4f;
        float ring = 0.0f, ringHz = 660.0f, mix = 1.0f;
    };

    void prepare (double sampleRate)
    {
        sr = sampleRate;
        for (auto& b : buf) b.prepare ((size_t) (sr * 3.0));
        for (int c = 0; c < 2; ++c)
        {
            for (auto& d : comb[c]) d.prepare ((size_t) (sr / 40.0) + 8);
            for (auto& o : combLp[c]) o.reset();
            for (auto& b : aa[c]) b.reset();
            for (auto& b : post[c]) b.reset();
            held[c] = 0; shPhase[c] = 1;
        }
        n = 0; lastSlot = INT64_MIN; sliceStart = 0; sliceLen = 1; sliceT = 0; freeBeats = 0;
        curDelay = prevDelay = 0; fade = 1.0f; grainT = 0; grainOffset = 0; lastHw = -1;
        ringEnv.prepare (sr, 5.0f, 250.0f);
    }

    void process (float* L, float* R, int nSamples, const Params& p, double bpm, double ppq, bool playing)
    {
        const bool stereo = R != nullptr;
        if (! p.on)
        {
            for (int i = 0; i < nSamples; ++i) { buf[0].push (L[i]); buf[1].push (stereo ? R[i] : L[i]); ++n; }
            lastSlot = INT64_MIN;
            return;
        }
        if (p.hardware != lastHw) configureHardware (p.hardware);

        const double spb = 60.0 / std::max (20.0, bpm) * sr;
        const double div = divisionBeats (p.division);
        const int fadeLen = std::max (16, (int) (sr * (0.0008 + 0.006 * (1.0 - p.declick))));   // shorter fade = clickier
        const float dipDepth = 0.9f * p.declick;                                               // gain dip at every chop
        const double grainLen = p.grainMs < 1.0f ? 0.0 : (double) p.grainMs * 0.001 * sr;
        const double maxSlop = 0.025 * sr * p.slop;
        const double maxSmear = 0.03 * sr * p.smear;
        const float ringFb = 0.80f + 0.15f * std::sqrt (p.ring);

        for (int i = 0; i < nSamples; ++i)
        {
            const float inL = L[i], inR = stereo ? R[i] : inL;
            buf[0].push (inL); buf[1].push (inR);
            ++n;

            // ---- slice grid
            const double beat = playing ? ppq + (double) i / spb : freeBeats;
            if (! playing) freeBeats += 1.0 / spb;
            const int64_t slot = (int64_t) std::floor (beat / div);
            if (slot != lastSlot)
            {
                const bool first = lastSlot == INT64_MIN;
                lastSlot = slot;
                sliceLen = std::max (32.0, div * spb);
                const bool doRepeat = ! first && rng.uni() < p.repeat && (double) (n - sliceStart) + sliceLen < (double) buf[0].size() - sr * 0.1;
                if (! doRepeat) sliceStart = n;          // fresh slice from "now"; otherwise replay the previous one
                sliceT = 0;
                grainT = 0;
                grainOffset = rng.uni() * maxSlop;
                startFade();
            }
            // ---- micro grains inside the slice (the "million chops" chatter)
            if (grainLen > 0.0 && grainT >= grainLen * (0.85 + 0.3 * rng.uni()))
            {
                grainT = 0;
                grainOffset = rng.uni() * maxSlop;
                startFade();
            }
            // smear: lag that swells and returns to zero over the slice
            const double ph = sliceT / sliceLen;
            const double s = std::sin (kPi * std::min (1.0, ph));
            const double smearLag = maxSmear * s * s;
            // delay = how far behind "now" the read head sits
            curDelay = (double) (n - sliceStart) - sliceT + smearLag + grainOffset + 1.0;
            sliceT += 1.0; grainT += 1.0;

            float g = 1.0f, wNew = 1.0f;
            if (fade < 1.0f)
            {
                fade = std::min (1.0f, fade + 1.0f / (float) fadeLen);
                wNew = fade;
                g = 1.0f - dipDepth * std::sin (kPi * fade);
            }
            float oL = readAt (0, curDelay), oR = readAt (1, curDelay);
            if (wNew < 1.0f)
            {
                const float pL = readAt (0, prevDelay), pR = readAt (1, prevDelay);
                oL = pL + (oL - pL) * wNew; oR = pR + (oR - pR) * wNew;
            }
            oL *= g; oR *= g;

            // ---- sampler colour
            colour (oL, oR);

            // ---- metallic ring (tuned comb bank that only rings while material is present)
            if (p.ring > 0.001f)
            {
                const float e = ringEnv.process (0.5f * (oL + oR));
                const float ringDrive = clampf (e * 6.0f, 0.0f, 1.0f);
                float rl = 0, rr = 0;
                static const float ratios[3] = { 1.0f, 2.01f, 2.997f };
                for (int k = 0; k < 3; ++k)
                {
                    for (int c = 0; c < 2; ++c)
                    {
                        const float d = (float) sr / (p.ringHz * ratios[k] * (c ? 1.004f : 1.0f));
                        float tap = comb[c][k].read (std::max (2.0f, d));
                        tap = combLp[c][k].lp (tap);
                        const float in = (c ? oR : oL) * 0.25f * ringDrive;
                        comb[c][k].push (sanitize (in + tap * ringFb));
                        (c ? rr : rl) += tap / (float) (k + 1);
                    }
                }
                oL += std::tanh (rl * 0.6f) * p.ring * 0.7f; oR += std::tanh (rr * 0.6f) * p.ring * 0.7f;
            }

            L[i] = inL + (oL - inL) * p.mix;
            if (stereo) R[i] = inR + (oR - inR) * p.mix;
        }
    }

private:
    static int juce_clamp (int d) { return d < 0 ? 0 : (d >= kNumDivs ? kNumDivs - 1 : d); }

    void startFade() { prevDelay = curDelay; fade = 0.0f; }

    inline float readAt (int c, double d) const
    {
        d = std::max (1.0, std::min (d, (double) buf[c].size() - 8.0));
        return buf[c].read ((float) d);
    }

    void configureHardware (int hw)
    {
        lastHw = hw;
        // bits, rate, anti-alias (0 = none → aliasing), output filter, drive
        float aaHz = 0, outHz = 20000, rate = (float) sr; bits = 24; drive = 0;
        switch (hw)
        {
            case HwMPC60:   bits = 12; rate = 40000; aaHz = 16000; outHz = 15000; drive = 0.25f; break;
            case HwMPC3000: bits = 16; rate = 44100; aaHz = 19000; outHz = 17000; drive = 0.35f; break;
            case HwSP1200:  bits = 12; rate = 26040; aaHz = 0;     outHz = 12500; drive = 0.3f;  break;
            case HwS950:    bits = 12; rate = 32000; aaHz = 14000; outHz = 9500;  drive = 0.15f; break;
            case HwMPC2000: bits = 16; rate = 44100; aaHz = 0;     outHz = 18500; drive = 0.15f; break;
            case HwDusty:   bits = 12; rate = 22050; aaHz = 9000;  outHz = 5200;  drive = 0.4f;  break;
            default: break;
        }
        rateInc = std::min (1.0f, rate / (float) sr);
        useAA = aaHz > 0; useOut = hw != HwClean;
        for (int c = 0; c < 2; ++c)
        {
            if (useAA) { aa[c][0].set (Biquad::LP, sr, aaHz, 0.54f); aa[c][1].set (Biquad::LP, sr, aaHz, 1.31f); }
            post[c][0].set (Biquad::LP, sr, outHz, 0.6f);
            post[c][1].set (Biquad::LowShelf, sr, 120.0f, 0.7f, hw == HwDusty ? 2.5f : 1.0f);
        }
    }

    inline void colour (float& l, float& r)
    {
        if (lastHw == HwClean) return;
        const float levels = std::pow (2.0f, bits - 1.0f);
        for (int c = 0; c < 2; ++c)
        {
            float x = c ? r : l;
            if (useAA) { x = aa[c][0].process (x); x = aa[c][1].process (x); }
            shPhase[c] += rateInc;
            if (shPhase[c] >= 1.0f) { shPhase[c] -= 1.0f; held[c] = std::round (x * levels) / levels; }
            x = held[c];
            if (drive > 0) x = std::tanh (x * (1.0f + drive * 2.0f)) / (1.0f + drive * 0.8f);
            if (useOut) { x = post[c][0].process (x); x = post[c][1].process (x); }
            (c ? r : l) = x;
        }
    }

    double sr = 44100.0;
    DelayLine buf[2];
    DelayLine comb[2][3];
    OnePole combLp[2][3];
    Biquad aa[2][2], post[2][2];
    EnvFollow ringEnv;
    Rng rng { 0x1A2Bu };
    int64_t n = 0, lastSlot = INT64_MIN, sliceStart = 0;
    double sliceLen = 1, sliceT = 0, grainT = 0, grainOffset = 0, freeBeats = 0;
    double curDelay = 0, prevDelay = 0;
    float fade = 1.0f, held[2] {}, shPhase[2] {}, rateInc = 1.0f, bits = 24, drive = 0;
    bool useAA = false, useOut = false;
    int lastHw = -1;
};
} // namespace pf
