#pragma once
// protofukr — WARP engine.
// Original implementations of the *ideas* behind Ableton Live's warp modes (no Ableton code):
//   Beats    : transient-segment playback with Loop Off / Loop Forward / Loop Back-and-Forth + transient envelope
//   Tones    : 2-voice pitch-preserving granular, grain size control
//   Texture  : 4-voice granular with flux (random grain position/length)
//   Re-Pitch : varispeed — pitch follows speed (tape / "screw" style)
//   Complex  : phase vocoder with transient phase reset and bin-shift transposition
//
// Two sources:
//   Capture  : a ring buffer of the live input; playback windows re-sync on the host grid (chop & screw by design)
//              or Freeze to loop the last captured window.
//   Sample   : a loaded audio file played locked to the host transport at Speed × host tempo.
#include "Common.h"
#include <juce_dsp/juce_dsp.h>
#include <atomic>
#include <complex>
#include <memory>

namespace pf
{
struct SampleData
{
    juce::AudioBuffer<float> audio;     // up to 2 channels
    double fileRate = 44100.0;
    std::vector<double> transients;     // source-sample positions, ascending
    std::vector<float> peaks;           // 512 peak values for display
    double estimatedBpm = 120.0;
    juce::String name;
};

class WarpEngine
{
public:
    enum Mode { ModeOff = 0, ModeCapture, ModeSample };
    enum Algo { Beats = 0, Tones, Texture, RePitch, Complex };
    enum LoopMode { LoopOff = 0, LoopForward, LoopBackForth };
    enum Preserve { PresTransients = 0, Pres16, Pres8, Pres4 };
    enum Direction { DirForward = 0, DirReverse, DirPingPong };

    struct Params
    {
        int mode = ModeOff, algo = RePitch, loopMode = LoopForward, preserve = PresTransients, direction = DirForward;
        float speed = 1.0f, pitch = 0.0f, grainMs = 80.0f, flux = 0.3f, envelope = 1.0f, mix = 1.0f;
        float captureBeats = 2.0f, sampleBpm = 120.0f;
        bool freeze = false, sync = true, freeRun = false;
    };

    static constexpr int kMaxBlock = 4096;

    void prepare (double sampleRate)
    {
        sr = sampleRate;
        int sz = 1; while (sz < (int) (sr * 10.0)) sz <<= 1;
        ringSize = sz; ringMask = (uint32_t) sz - 1;
        ring[0].assign ((size_t) sz, 0.0f); ring[1].assign ((size_t) sz, 0.0f);
        markers.assign (1024, 0); gridMarks.assign (1024, 0);
        tBuf.assign (kMaxBlock, 0.0); gBuf.assign (kMaxBlock, 1.0f); jBuf.assign (kMaxBlock, 0);
        pvN = sr > 60000.0 ? 4096 : 2048; pvH = pvN / 4;
        pvFft = std::make_unique<juce::dsp::FFT> ((int) std::log2 ((double) pvN));
        for (int c = 0; c < 2; ++c)
        {
            pv[c].acc.assign ((size_t) (2 * pvN), 0.0f);
            pv[c].phase.assign ((size_t) pvN, 0.0f);
            pv[c].prevMag.assign ((size_t) pvN, 0.0f);
        }
        pvA.assign ((size_t) pvN, {}); pvB.assign ((size_t) pvN, {}); pvOut.assign ((size_t) pvN, {}); pvTmp.assign ((size_t) pvN, {});
        pvMag.assign ((size_t) pvN, 0.0f); pvFreq.assign ((size_t) pvN, 0.0f); pvPh2.assign ((size_t) pvN, 0.0f);
        pvWin.assign ((size_t) pvN, 0.0f);
        for (int i = 0; i < pvN; ++i) pvWin[(size_t) i] = 0.5f - 0.5f * std::cos (kTau * (float) i / (float) pvN);
        onsetFast.prepare (sr, 0.5f, 30.0f); onsetSlow.prepare (sr, 15.0f, 120.0f);
        onsetHP.set (Biquad::HP, sr, 150.0f, 0.707f);
        reset();
    }

    void reset()
    {
        for (auto& r : ring) std::fill (r.begin(), r.end(), 0.0f);
        writeAbs = 0; markerCount = gridCount = 0; lastOnset = -100000;
        winCounter = 0; winElapsed = 0; lastWinIndex = INT64_MIN; frozen = false;
        for (auto& g : grains) g.active = false;
        hopCountdown = 0; beat = {}; oldVoice = {};
        pvReset = true; pvFill = 0;
        for (int c = 0; c < 2; ++c) { std::fill (pv[c].acc.begin(), pv[c].acc.end(), 0.0f); pv[c].outPos = 0; }
        lastT = 0.0; ws = 0.0; lastGridIdx = INT64_MIN;
    }

    // Swap sample data (called with lock held by owner).
    void setSample (std::shared_ptr<SampleData> s) { sample = std::move (s); beat = {}; oldVoice = {}; pvReset = true; }
    std::shared_ptr<SampleData> getSample() const { return sample; }

    // UI feedback
    std::atomic<float> playheadNorm { 0.0f };
    std::atomic<float> windowNorm { 0.0f };

    int lookaheadFor (const Params& p) const
    {
        const float pr = std::exp2 (p.pitch / 12.0f);
        switch (p.algo)
        {
            case Tones: case Texture: return (int) (p.grainMs * 0.001f * (float) sr * 1.6f * std::max (1.0f, pr)) + 8;
            case Complex:             return (int) ((float) pvN * std::max (1.0f, pr)) + 8;
            default:                  return 8;
        }
    }

    void process (float* L, float* R, int n, const Params& p, double bpm, double ppq, bool playing)
    {
        // Always keep the capture ring fed (unless frozen) so switching modes is seamless.
        const bool wantFreeze = p.mode == ModeCapture && p.freeze;
        if (wantFreeze && ! frozen) startFreeze (p, bpm);
        if (! wantFreeze) frozen = false;
        if (! frozen) writeInput (L, R, n, p, bpm, ppq, playing);

        if (p.mode == ModeOff) return;
        if (p.mode == ModeSample && (! sample || sample->audio.getNumSamples() < 64)) return;
        n = std::min (n, kMaxBlock);

        // ---- 1. compute source trajectory t[i] -----------------------------------------
        if (p.mode == ModeCapture) trajectoryCapture (n, p, bpm, ppq, playing);
        else if (! trajectorySample (n, p, bpm, ppq, playing))
        {
            for (int i = 0; i < n; ++i) { L[i] *= (1.0f - p.mix); if (R) R[i] *= (1.0f - p.mix); }
            return;
        }

        // ---- 2. render ---------------------------------------------------------------
        const float pitchRatio = std::exp2 (p.pitch / 12.0f);
        const double srcRatio = p.mode == ModeSample ? sample->fileRate / sr : 1.0;
        float outL[kMaxBlock], outR[kMaxBlock];
        switch (p.algo)
        {
            case RePitch: renderRePitch (outL, outR, n); break;
            case Beats:   renderBeats (outL, outR, n, p, (float) (pitchRatio * srcRatio), bpm); break;
            case Tones: case Texture: renderGrains (outL, outR, n, p, (float) (pitchRatio * srcRatio)); break;
            case Complex: renderPV (outL, outR, n, pitchRatio, srcRatio); break;
            default: break;
        }
        const bool stereo = R != nullptr;
        for (int i = 0; i < n; ++i)
        {
            const float g = (p.algo == Tones || p.algo == Texture) ? 1.0f : gBuf[(size_t) i];
            L[i] = L[i] * (1.0f - p.mix) + sanitize (outL[i] * g) * p.mix;
            if (stereo) R[i] = R[i] * (1.0f - p.mix) + sanitize (outR[i] * g) * p.mix;
        }
    }

    // Offline helpers for sample loading (message thread)
    static void analyseSample (SampleData& s)
    {
        const int n = s.audio.getNumSamples(), nc = s.audio.getNumChannels();
        s.peaks.assign (512, 0.0f);
        for (int i = 0; i < n; ++i)
        {
            float v = 0; for (int c = 0; c < nc; ++c) v = std::max (v, std::abs (s.audio.getSample (c, i)));
            auto& pk = s.peaks[(size_t) std::min (511, (int) ((int64_t) i * 512 / std::max (1, n)))];
            pk = std::max (pk, v);
        }
        EnvFollow f, sl; f.prepare (s.fileRate, 0.5f, 30.0f); sl.prepare (s.fileRate, 15.0f, 120.0f);
        Biquad hp; hp.set (Biquad::HP, s.fileRate, 150.0f, 0.707f);
        s.transients.clear(); s.transients.push_back (0.0);
        int64_t last = 0;
        for (int i = 0; i < n; ++i)
        {
            float m = 0; for (int c = 0; c < nc; ++c) m += s.audio.getSample (c, i);
            const float d = std::abs (hp.process (m / (float) std::max (1, nc)));
            const float a = f.process (d), b = sl.process (d);
            if (a > b * 1.9f && a > 0.02f && i - last > (int64_t) (0.06 * s.fileRate)) { s.transients.push_back ((double) i); last = i; }
        }
        const double secs = (double) n / s.fileRate;
        s.estimatedBpm = 120.0;
        for (int bars = 1; bars <= 64; bars *= 2)
        {
            const double bpm = bars * 4.0 * 60.0 / secs;
            if (bpm >= 75.0 && bpm < 150.0) { s.estimatedBpm = bpm; break; }
        }
    }

private:
    // ===================================================================== capture ring
    void writeInput (const float* L, const float* R, int n, const Params& p, double bpm, double ppq, bool playing)
    {
        const double spb = 60.0 / std::max (20.0, bpm) * sr;
        const double div = p.preserve == Pres16 ? 0.25 : (p.preserve == Pres8 ? 0.5 : 1.0);
        for (int i = 0; i < n; ++i)
        {
            const float l = L[i], r = R ? R[i] : l;
            ring[0][(size_t) (writeAbs & ringMask)] = l;
            ring[1][(size_t) (writeAbs & ringMask)] = r;
            // onset detection → transient markers
            const float d = std::abs (onsetHP.process (0.5f * (l + r)));
            const float a = onsetFast.process (d), b = onsetSlow.process (d);
            if (a > b * 1.9f && a > 0.02f && writeAbs - lastOnset > (int64_t) (0.06 * sr))
            {
                markers[(size_t) (markerCount++ & 1023)] = writeAbs; lastOnset = writeAbs;
            }
            // grid markers
            const double beatPos = playing ? ppq + (double) i / spb : (double) writeAbs / spb;
            const int64_t gi = (int64_t) std::floor (beatPos / div);
            if (gi != lastGridIdx) { gridMarks[(size_t) (gridCount++ & 1023)] = writeAbs; lastGridIdx = gi; }
            ++writeAbs;
        }
    }

    void startFreeze (const Params& p, double bpm)
    {
        frozen = true;
        const double spb = 60.0 / std::max (20.0, bpm) * sr;
        const int L = lookaheadFor (p);
        freezeLen = std::min ((double) p.captureBeats * spb, (double) ringSize * 0.8 - L);
        freezeStart = (double) writeAbs - L - freezeLen;
        winElapsed = 0;
        beat = {}; pvReset = true;
    }

    inline float ringAt (int c, double pos) const
    {
        const double fl = std::floor (pos);
        const float t = (float) (pos - fl);
        const int64_t i = (int64_t) fl;
        const auto& r = ring[c];
        auto at = [&] (int64_t k) { return r[(size_t) ((uint64_t) k & ringMask)]; };
        return hermite (at (i - 1), at (i), at (i + 1), at (i + 2), t);
    }

    inline float sampleAt (int c, double pos) const
    {
        const auto& a = sample->audio;
        const int n = a.getNumSamples();
        const int ch = std::min (c, a.getNumChannels() - 1);
        const float* d = a.getReadPointer (ch);
        double fl = std::floor (pos);
        const float t = (float) (pos - fl);
        int64_t i = (int64_t) fl;
        auto at = [&] (int64_t k) { k %= n; if (k < 0) k += n; return d[k]; };
        return hermite (at (i - 1), at (i), at (i + 1), at (i + 2), t);
    }

    inline float src (int c, double pos) const { return curMode == ModeSample ? sampleAt (c, pos) : ringAt (c, pos); }

    void trajectoryCapture (int n, const Params& p, double bpm, double ppq, bool playing)
    {
        curMode = ModeCapture;
        const double spb = 60.0 / std::max (20.0, bpm) * sr;
        const int L = lookaheadFor (p);
        const float speed = std::max (0.05f, p.speed);
        const double fade = 0.004 * sr;
        double P = (double) p.captureBeats * spb;
        P = std::min (P, ((double) ringSize * 0.8 - L) / std::max (1.0f, speed));
        const int64_t startAbs = writeAbs - n;

        for (int i = 0; i < n; ++i)
        {
            const double now = (double) (startAbs + i) - L;
            jBuf[(size_t) i] = 0;
            if (frozen)
            {
                double u = winElapsed * speed;
                double pos;
                const double len = std::max (64.0, freezeLen);
                if (p.direction == DirForward)       pos = std::fmod (u, len);
                else if (p.direction == DirReverse)  pos = len - std::fmod (u, len);
                else { const double m = std::fmod (u, 2.0 * len); pos = m < len ? m : 2.0 * len - m; }
                const double edge = p.direction == DirPingPong ? 1.0e9 : std::min (pos, len - pos);
                gBuf[(size_t) i] = (float) std::min (1.0, edge / fade);
                tBuf[(size_t) i] = freezeStart + pos;
                winElapsed += 1.0;
                windowNorm.store ((float) (pos / len));
                continue;
            }

            // window trigger: host grid when synced & playing, else free counter
            bool trigger = false;
            if (p.sync && playing)
            {
                const int64_t wi = (int64_t) std::floor ((ppq + (double) i / spb) / p.captureBeats);
                if (wi != lastWinIndex) { lastWinIndex = wi; trigger = true; }
            }
            else
            {
                lastWinIndex = INT64_MIN;
                if (winElapsed >= P) trigger = true;
            }
            if (trigger)
            {
                winElapsed = 0;
                if (p.direction == DirForward)      ws = now - std::max (0.0, ((double) speed - 1.0) * P);
                else if (p.direction == DirReverse) ws = now;
                else                                ws = now - std::max (0.0, ((double) speed - 1.0) * P * 0.5);
                jBuf[(size_t) i] = 1;
            }
            const double e = winElapsed, u = e * speed;
            double t;
            if (p.direction == DirForward)      t = ws + u;
            else if (p.direction == DirReverse) t = ws - u;
            else { const double half = P * 0.5 * speed; t = u < half ? ws + u : ws + 2.0 * half - u; }
            t = std::min (t, now);
            tBuf[(size_t) i] = t;
            // dip around window boundaries (not needed when speed == 1 forward: continuous)
            const bool continuous = p.direction == DirForward && std::abs (speed - 1.0f) < 1.0e-4f;
            float g = 1.0f;
            if (! continuous)
            {
                const double toEnd = P - e;
                g = (float) std::min ({ 1.0, e / fade, std::max (0.0, toEnd) / fade + (p.sync && playing ? 1.0 : 0.0) });
            }
            gBuf[(size_t) i] = g;
            winElapsed += 1.0;
            windowNorm.store ((float) std::min (1.0, e / std::max (1.0, P)));
        }
        playheadNorm.store (windowNorm.load());
    }

    bool trajectorySample (int n, const Params& p, double bpm, double ppq, bool playing)
    {
        curMode = ModeSample;
        if (! playing && ! p.freeRun) { beat = {}; return false; }
        const double spbHost = 60.0 / std::max (20.0, bpm) * sr;
        const double fileSpb = 60.0 / std::max (20.0f, p.sampleBpm) * sample->fileRate;   // source samples per sample-beat
        const double len = (double) sample->audio.getNumSamples();
        const double lenBeats = len / fileSpb;
        const double fade = 0.003 * sr;
        for (int i = 0; i < n; ++i)
        {
            double beats;
            if (playing) beats = (ppq + (double) i / spbHost) * p.speed;
            else { beats = freeBeats * p.speed; freeBeats += 1.0 / spbHost; }
            double pos;
            double b = std::fmod (beats, lenBeats); if (b < 0) b += lenBeats;
            if (p.direction == DirForward) pos = b;
            else if (p.direction == DirReverse) pos = lenBeats - b;
            else { double m = std::fmod (beats, 2.0 * lenBeats); if (m < 0) m += 2.0 * lenBeats; pos = m < lenBeats ? m : 2.0 * lenBeats - m; }
            const double t = pos * fileSpb;
            const double edgeSrc = p.direction == DirPingPong ? 1.0e12 : std::min (t, len - t);
            const double edgeOut = edgeSrc / std::max (1.0e-6, (double) p.speed * fileSpb / spbHost);
            gBuf[(size_t) i] = (float) std::min (1.0, edgeOut / fade);
            jBuf[(size_t) i] = (i > 0 && std::abs (t - tBuf[(size_t) i - 1]) > 64.0 * std::max (1.0, sample->fileRate / sr) * (double) std::max (1.0f, p.speed * 8.0f)) ? 1 : 0;
            if (i == 0 && std::abs (t - lastT) > 4096.0) jBuf[0] = 1;
            tBuf[(size_t) i] = t;
        }
        lastT = tBuf[(size_t) n - 1];
        playheadNorm.store ((float) (lastT / len));
        return true;
    }

    // ===================================================================== Re-Pitch
    void renderRePitch (float* oL, float* oR, int n)
    {
        for (int i = 0; i < n; ++i) { oL[i] = src (0, tBuf[(size_t) i]); oR[i] = src (1, tBuf[(size_t) i]); }
    }

    // ===================================================================== Beats
    struct Voice { double start = 0, end = 1.0e18, local = 0, rate = 1, loopLen = 0; int dir = 1; double elapsed = 0; float gain = 0; bool active = false; bool silent = false; };
    Voice beat, oldVoice;

    void findSegment (double t, const Params& p, double bpm, double& s0, double& s1) const
    {
        s0 = -1.0e18; s1 = 1.0e18;
        if (curMode == ModeSample)
        {
            if (p.preserve == PresTransients && ! sample->transients.empty())
            {
                const auto& tr = sample->transients;
                auto it = std::upper_bound (tr.begin(), tr.end(), t);
                s1 = it == tr.end() ? (double) sample->audio.getNumSamples() : *it;
                s0 = it == tr.begin() ? 0.0 : *(it - 1);
            }
            else
            {
                const double div = p.preserve == Pres16 ? 0.25 : (p.preserve == Pres8 ? 0.5 : 1.0);
                const double g = div * 60.0 / std::max (20.0f, p.sampleBpm) * sample->fileRate;
                s0 = std::floor (t / g) * g; s1 = s0 + g;
            }
            return;
        }
        juce::ignoreUnused (bpm);
        const auto& mk = p.preserve == PresTransients ? markers : gridMarks;
        const int64_t cnt = p.preserve == PresTransients ? markerCount : gridCount;
        const int64_t first = std::max<int64_t> (0, cnt - 1024);
        for (int64_t k = cnt - 1; k >= first; --k)
        {
            const double m = (double) mk[(size_t) (k & 1023)];
            if (m <= t) { s0 = m; break; }
            s1 = m;
        }
        if (s0 < -1.0e17) s0 = t;
    }

    void renderBeats (float* oL, float* oR, int n, const Params& p, float localRate, double bpm)
    {
        const double fadeLen = 0.003 * sr;
        const float env = clampf (p.envelope, 0.0f, 1.0f);
        const double envTau = (0.012 + (double) (env * env) * 1.5) * sr;
        for (int i = 0; i < n; ++i)
        {
            const double t = tBuf[(size_t) i];
            const bool outside = ! beat.active || t < beat.start - 1.0 || t >= beat.end;
            if (jBuf[(size_t) i] || outside)
            {
                if (beat.active && ! beat.silent) { oldVoice = beat; oldVoice.gain = 1.0f; }
                double s0, s1; findSegment (t, p, bpm, s0, s1);
                beat = {}; beat.active = true; beat.start = s0; beat.end = s1; beat.local = t - s0; beat.rate = localRate;
                const double segLen = std::max (64.0, std::min (s1 - s0, 4.0 * sr));
                beat.loopLen = clampf ((float) (segLen * 0.5), (float) (0.01 * sr), (float) (0.25 * sr));
                beat.elapsed = 0;
            }
            // advance
            beat.local += beat.rate * beat.dir;
            const double limit = curMode == ModeCapture ? std::min (beat.end, (double) writeAbs - 4.0) - beat.start : beat.end - beat.start;
            if (beat.local >= limit && ! beat.silent)
            {
                if (p.loopMode == LoopOff) beat.silent = true;
                else if (p.loopMode == LoopForward)
                {
                    oldVoice = beat; oldVoice.gain = 1.0f;
                    beat.local = std::max (0.0, limit - beat.loopLen);
                }
                else { beat.dir = -1; beat.local = limit; }
            }
            if (p.loopMode == LoopBackForth && beat.dir < 0 && beat.local <= std::max (0.0, limit - beat.loopLen)) beat.dir = 1;

            float g = beat.silent ? 0.0f : (float) std::exp (-beat.elapsed / envTau);
            if (env >= 0.999f && ! beat.silent) g = 1.0f;
            if (beat.elapsed < 64.0) g *= (float) (beat.elapsed / 64.0) * 0.6f + 0.4f;
            beat.elapsed += 1.0;
            const double pos = beat.start + beat.local;
            float l = g * src (0, pos), r = g * src (1, pos);
            if (oldVoice.gain > 0.0f)
            {
                oldVoice.local += oldVoice.rate * oldVoice.dir;
                const double op = oldVoice.start + oldVoice.local;
                const float og = oldVoice.gain * (oldVoice.silent ? 0.0f : 1.0f);
                l += og * src (0, op); r += og * src (1, op);
                oldVoice.gain = std::max (0.0f, oldVoice.gain - (float) (1.0 / fadeLen));
            }
            oL[i] = l; oR[i] = r;
        }
    }

    // ===================================================================== Tones / Texture
    struct Grain { double pos = 0; float rate = 1, age = 0, len = 1; bool active = false; };
    Grain grains[16];
    float hopCountdown = 0;

    void renderGrains (float* oL, float* oR, int n, const Params& p, float rate)
    {
        const bool texture = p.algo == Texture;
        const float G = clampf (p.grainMs, 5.0f, 500.0f) * 0.001f * (float) sr;
        const int overlap = texture ? 4 : 2;
        const float hop = G / (float) overlap;
        const float norm = texture ? 0.5f : 1.0f;
        for (int i = 0; i < n; ++i)
        {
            if (hopCountdown <= 0.0f)
            {
                hopCountdown += texture ? hop * (1.0f + p.flux * 0.6f * rng.bi()) : hop;
                for (auto& g : grains)
                    if (! g.active)
                    {
                        g.active = true; g.age = 0;
                        g.len = texture ? G * (1.0f + 0.5f * p.flux * rng.bi()) : G;
                        double pos = tBuf[(size_t) i];
                        if (texture) pos -= (double) (p.flux * G * rng.uni() * 1.5f);
                        g.pos = pos; g.rate = rate * (texture ? (1.0f + 0.004f * p.flux * rng.bi()) : 1.0f);
                        break;
                    }
            }
            hopCountdown -= 1.0f;
            float l = 0, r = 0;
            for (auto& g : grains)
            {
                if (! g.active) continue;
                const float w = 0.5f - 0.5f * std::cos (kTau * g.age / g.len);
                l += w * src (0, g.pos); r += w * src (1, g.pos);
                g.pos += g.rate; g.age += 1.0f;
                if (g.age >= g.len) g.active = false;
            }
            oL[i] = l * norm; oR[i] = r * norm;
        }
    }

    // ===================================================================== Complex (phase vocoder)
    struct PVChan { std::vector<float> acc, phase, prevMag; int outPos = 0; };
    PVChan pv[2];
    std::unique_ptr<juce::dsp::FFT> pvFft;
    std::vector<std::complex<float>> pvA, pvB, pvOut, pvTmp;
    std::vector<float> pvMag, pvFreq, pvPh2, pvWin;
    int pvN = 2048, pvH = 512, pvFill = 0;
    bool pvReset = true;

    static inline float princarg (float x) { return x - kTau * std::floor ((x + kPi) / kTau); }

    void renderPV (float* oL, float* oR, int n, float pitchRatio, double srcRatio)
    {
        for (int i = 0; i < n; ++i)
        {
            if (jBuf[(size_t) i]) pvReset = true;
            if (pvFill == 0) pvFrame (tBuf[(size_t) i], pitchRatio, srcRatio);
            for (int c = 0; c < 2; ++c)
            {
                auto& s = pv[c];
                (c ? oR : oL)[i] = s.acc[(size_t) pvFill];
            }
            if (++pvFill >= pvH)
            {
                pvFill = 0;
                for (int c = 0; c < 2; ++c)
                {
                    auto& a = pv[c].acc;
                    std::copy (a.begin() + pvH, a.end(), a.begin());
                    std::fill (a.end() - pvH, a.end(), 0.0f);
                }
            }
        }
    }

    void pvFrame (double t, float pitchRatio, double srcRatio)
    {
        const int N = pvN, half = N / 2;
        const float binW = kTau / (float) N;
        for (int c = 0; c < 2; ++c)
        {
            auto& s = pv[c];
            for (int j = 0; j < N; ++j)
            {
                pvTmp[(size_t) j] = { src (c, t + (double) j * srcRatio) * pvWin[(size_t) j], 0.0f };
                pvOut[(size_t) j] = { src (c, t + ((double) j + pvH) * srcRatio) * pvWin[(size_t) j], 0.0f };
            }
            pvFft->perform (pvTmp.data(), pvA.data(), false);
            pvFft->perform (pvOut.data(), pvB.data(), false);

            float fluxUp = 0, total = 1.0e-9f;
            for (int k = 0; k <= half; ++k)
            {
                const float m = std::abs (pvB[(size_t) k]);
                const float ph1 = std::arg (pvA[(size_t) k]), ph2 = std::arg (pvB[(size_t) k]);
                const float expected = binW * (float) k * (float) pvH;
                const float dev = princarg (ph2 - ph1 - expected);
                pvMag[(size_t) k] = m;
                pvFreq[(size_t) k] = (expected + dev) / (float) pvH;   // rad / sample
                pvPh2[(size_t) k] = ph2;
                const float d = m - s.prevMag[(size_t) k];
                if (d > 0) fluxUp += d;
                total += m;
                s.prevMag[(size_t) k] = m;
            }
            const bool transient = fluxUp > 0.35f * total && total > 1.0f;
            const bool resetPh = pvReset || transient;

            for (auto& v : pvOut) v = {};
            std::vector<float>& ph = s.phase;
            // bin-shift transposition
            for (int k = 0; k <= half; ++k)
            {
                const int k2 = (int) std::lround ((float) k * pitchRatio);
                if (k2 < 0 || k2 > half) continue;
                const float w = pvFreq[(size_t) k] * pitchRatio;
                float newPh = resetPh ? pvPh2[(size_t) k] : ph[(size_t) k2] + w * (float) pvH;
                ph[(size_t) k2] = princarg (newPh);
                pvOut[(size_t) k2] += std::polar (pvMag[(size_t) k], ph[(size_t) k2]);
            }
            for (int k = 1; k < half; ++k) pvOut[(size_t) (N - k)] = std::conj (pvOut[(size_t) k]);
            pvFft->perform (pvOut.data(), pvTmp.data(), true);
            const float norm = 1.0f / 1.5f;
            for (int j = 0; j < N; ++j) s.acc[(size_t) j] += pvTmp[(size_t) j].real() * pvWin[(size_t) j] * norm;
        }
        pvReset = false;
    }

    // ===================================================================== state
    double sr = 44100.0;
    std::vector<float> ring[2];
    int ringSize = 0; uint32_t ringMask = 0;
    int64_t writeAbs = 0, lastOnset = 0, lastWinIndex = INT64_MIN, lastGridIdx = INT64_MIN;
    std::vector<int64_t> markers, gridMarks; int64_t markerCount = 0, gridCount = 0;
    EnvFollow onsetFast, onsetSlow; Biquad onsetHP;
    std::vector<double> tBuf; std::vector<float> gBuf; std::vector<uint8_t> jBuf;
    double ws = 0, winElapsed = 0, freezeStart = 0, freezeLen = 0, lastT = 0, freeBeats = 0;
    int64_t winCounter = 0;
    bool frozen = false;
    int curMode = ModeCapture;
    std::shared_ptr<SampleData> sample;
    Rng rng { 0x5EEDu };
};
} // namespace pf
