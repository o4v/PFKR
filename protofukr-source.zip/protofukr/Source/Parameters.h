#pragma once
// protofukr — parameter IDs, layout and choice lists. Every control is a host parameter, so
// FL Studio can record / link automation for all of it (Tools ▸ Last tweaked ▸ Create automation clip).
#include <juce_audio_processors/juce_audio_processors.h>

namespace pid
{
// global
inline constexpr const char* inGain = "inGain", *outGain = "outGain", *mix = "mix", *mono = "mono", *width = "width", *order = "order";
// warp
inline constexpr const char* warpMode = "warpMode", *warpAlgo = "warpAlgo", *warpSpeed = "warpSpeed", *warpPitch = "warpPitch",
    *warpGrain = "warpGrain", *warpFlux = "warpFlux", *warpLoop = "warpLoop", *warpEnv = "warpEnv", *warpPreserve = "warpPreserve",
    *warpLength = "warpLength", *warpFreeze = "warpFreeze", *warpSync = "warpSync", *warpDir = "warpDir", *warpBpm = "warpBpm",
    *warpFreeRun = "warpFreeRun", *warpMix = "warpMix";
// lofi
inline constexpr const char* lofiOn = "lofiOn", *codecType = "codecType", *codecSR = "codecSR", *codecKbps = "codecKbps",
    *codecBits = "codecBits", *codecFrame = "codecFrame", *codecStereo = "codecStereo", *codecSwirl = "codecSwirl",
    *codecDither = "codecDither", *lofiMix = "lofiMix";
// tape
inline constexpr const char* tapeOn = "tapeOn", *hissOn = "hissOn", *hissType = "hissType", *hissLevel = "hissLevel", *hissTone = "hissTone",
    *hissSc = "hissSc", *hissScAmt = "hissScAmt", *hissScAtk = "hissScAtk", *hissScRel = "hissScRel",
    *wow = "wow", *flutter = "flutter", *tapeDrive = "tapeDrive";
// dynamics
inline constexpr const char* transMode = "transMode", *transAttack = "transAttack", *transSustain = "transSustain", *transFocus = "transFocus",
    *compOn = "compOn", *compStyle = "compStyle", *compThresh = "compThresh", *compRatio = "compRatio", *compAttack = "compAttack",
    *compRelease = "compRelease", *compKnee = "compKnee", *compMakeup = "compMakeup", *compMix = "compMix";
// larp resampler (qaeru mode) + output
inline constexpr const char* larpOn = "larpOn", *larpDiv = "larpDiv", *larpHw = "larpHw", *larpGrain = "larpGrain", *larpSlop = "larpSlop",
    *larpRepeat = "larpRepeat", *larpDeclick = "larpDeclick",
    *larpMix = "larpMix", *monoBelow = "monoBelow", *scareBoost = "scareBoost",
    *tapeAzimuth = "tapeAzimuth", *tapeHfCut = "tapeHfCut", *tapeHfRes = "tapeHfRes", *bassKeep = "bassKeep", *bassLift = "bassLift";
// inserts (prefix fx1 / fx2)
inline juce::String fx (int slot, const char* suffix) { return "fx" + juce::String (slot) + suffix; }
} // namespace pid

namespace choices
{
inline const juce::StringArray warpMode   { "Off", "Capture", "Sample" };
inline const juce::StringArray warpAlgo   { "Beats", "Tones", "Texture", "Re-Pitch", "Complex" };
inline const juce::StringArray warpLoop   { "Loop Off", "Loop Forward", "Loop Back-and-Forth" };
inline const juce::StringArray warpPres   { "Transients", "1/16", "1/8", "1/4" };
inline const juce::StringArray warpLength { "1/16", "1/8", "1/4", "1/2", "1 Bar", "2 Bars", "4 Bars" };
inline const float warpLengthBeats[]      { 0.25f, 0.5f, 1.0f, 2.0f, 4.0f, 8.0f, 16.0f };
inline const juce::StringArray warpDir    { "Forward", "Reverse", "Ping-Pong" };
inline const juce::StringArray codecType  { "Clean", "ZOH Crush", "Resample", "MP3 '08", "AAC", "Real '99", "GSM Phone" };
inline const juce::StringArray codecFrame { "Auto", "Low Latency", "Short", "Long", "Huge" };
inline const juce::StringArray codecStereo{ "Stereo", "Joint", "Mono" };
inline const juce::StringArray hissType   { "Cheap Ferric (UR-ish)", "Ferric Normal", "Chrome CrO2", "Metal", "Microcassette",
                                            "VHS Linear", "CRT Broadcast", "Vinyl Dust", "Memphis Dub Tape" };
inline const juce::StringArray hissSc     { "Constant", "All Input", "Duck Input", "Low Band (kick)", "High Band (hats)", "Sidechain Bus",
                                            "Duck Input (Deep)", "All Input (Deep)" };
inline const juce::StringArray transMode  { "Off", "Sharp", "Fat", "Balanced", "Punch", "Snap", "Smack" };
inline const juce::StringArray compStyle  { "Clean VCA", "Opto", "FET", "Glue", "Brick", "Pump" };
inline const juce::StringArray order      { "Tape > Codec", "Codec > Tape" };
inline const juce::StringArray larpDiv    { "1/1", "1/2", "1/4", "1/8", "1/16", "1/32", "1/64", "1/8T", "1/16T" };
inline const juce::StringArray larpHw     { "Clean", "MPC60 (12-bit)", "MPC3000", "SP-1200 (26k)", "S950 (filtered)", "MPC2000XL", "Dusty Sampler" };
juce::StringArray fxTypes();
} // namespace choices

juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();
