#include "Parameters.h"
#include "dsp/InsertFX.h"

juce::StringArray choices::fxTypes()
{
    juce::StringArray s;
    for (int i = 0; i < pf::InsertFX::NumTypes; ++i) s.add (pf::InsertFX::typeName (i));
    return s;
}

namespace
{
using APF = juce::AudioParameterFloat;
using APC = juce::AudioParameterChoice;
using APB = juce::AudioParameterBool;
using Attr = juce::AudioParameterFloatAttributes;

// Typing "22.05k", "22050", "22050 Hz" etc. all work.
// "22.05k" → 22050 for frequencies; for everything else 'k' is just part of the unit (e.g. "64k" kbps)
float parseNumber (const juce::String& text, bool isHz)
{
    auto t = text.trim().toLowerCase();
    const float mult = (isHz && t.containsChar ('k')) ? 1000.0f : 1.0f;
    return t.retainCharacters ("0123456789.-").getFloatValue() * mult;
}

Attr unit (juce::String suffix, int decimals)
{
    return Attr()
        .withStringFromValueFunction ([suffix, decimals] (float v, int) { return juce::String (v, decimals) + suffix; })
        .withValueFromStringFunction ([isHz = suffix.trim() == "Hz"] (const juce::String& s) { return parseNumber (s, isHz); })
        .withLabel (suffix.trim());
}

std::unique_ptr<APF> fl (const juce::String& id, const juce::String& name, float lo, float hi, float def,
                         juce::String suffix = {}, int decimals = 1, float centre = -1.0f, float step = 0.0f)
{
    juce::NormalisableRange<float> r (lo, hi, step);
    if (centre > lo && centre < hi) r.setSkewForCentre (centre);
    return std::make_unique<APF> (juce::ParameterID { id, 1 }, name, r, def, unit (suffix, decimals));
}

std::unique_ptr<APF> pct (const juce::String& id, const juce::String& name, float def)
{
    return fl (id, name, 0.0f, 100.0f, def, " %", 0);
}

std::unique_ptr<APC> ch (const juce::String& id, const juce::String& name, const juce::StringArray& c, int def)
{
    return std::make_unique<APC> (juce::ParameterID { id, 1 }, name, c, def);
}

std::unique_ptr<APB> bl (const juce::String& id, const juce::String& name, bool def)
{
    return std::make_unique<APB> (juce::ParameterID { id, 1 }, name, def);
}
} // namespace

juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout L;

    auto global = std::make_unique<juce::AudioProcessorParameterGroup> ("global", "Global", "|");
    global->addChild (fl (pid::inGain, "Input Gain", -24.0f, 24.0f, 0.0f, " dB", 1));
    global->addChild (fl (pid::outGain, "Output Gain", -24.0f, 24.0f, 0.0f, " dB", 1));
    global->addChild (pct (pid::mix, "Global Mix", 100.0f));
    global->addChild (bl (pid::mono, "Mono", false));
    global->addChild (fl (pid::width, "Stereo Width", 0.0f, 200.0f, 100.0f, " %", 0));
    global->addChild (ch (pid::order, "Chain Order", choices::order, 0));
    L.add (std::move (global));

    auto warp = std::make_unique<juce::AudioProcessorParameterGroup> ("warp", "Warp", "|");
    warp->addChild (ch (pid::warpMode, "Warp Mode", choices::warpMode, 0));
    warp->addChild (ch (pid::warpAlgo, "Warp Algorithm", choices::warpAlgo, 3));
    warp->addChild (fl (pid::warpSpeed, "Warp Speed", 0.1f, 2.0f, 1.0f, " x", 3, 1.0f));
    warp->addChild (fl (pid::warpPitch, "Warp Pitch", -24.0f, 24.0f, 0.0f, " st", 2));
    warp->addChild (fl (pid::warpGrain, "Grain Size", 5.0f, 500.0f, 80.0f, " ms", 1, 80.0f));
    warp->addChild (pct (pid::warpFlux, "Flux", 30.0f));
    warp->addChild (ch (pid::warpLoop, "Transient Loop", choices::warpLoop, 1));
    warp->addChild (pct (pid::warpEnv, "Transient Envelope", 100.0f));
    warp->addChild (ch (pid::warpPreserve, "Preserve", choices::warpPres, 0));
    warp->addChild (ch (pid::warpLength, "Capture Length", choices::warpLength, 3));
    warp->addChild (bl (pid::warpFreeze, "Freeze", false));
    warp->addChild (bl (pid::warpSync, "Grid Sync", true));
    warp->addChild (ch (pid::warpDir, "Direction", choices::warpDir, 0));
    warp->addChild (fl (pid::warpBpm, "Sample BPM", 20.0f, 300.0f, 120.0f, " bpm", 2));
    warp->addChild (bl (pid::warpFreeRun, "Sample Free Run", false));
    warp->addChild (pct (pid::warpMix, "Warp Mix", 100.0f));
    L.add (std::move (warp));

    auto lofi = std::make_unique<juce::AudioProcessorParameterGroup> ("lofi", "Lofi", "|");
    lofi->addChild (bl (pid::lofiOn, "Lofi On", false));
    lofi->addChild (ch (pid::codecType, "Codec", choices::codecType, 3));
    lofi->addChild (fl (pid::codecSR, "Sample Rate", 500.0f, 48000.0f, 22050.0f, " Hz", 0, 11025.0f, 1.0f));
    lofi->addChild (fl (pid::codecKbps, "Bitrate", 8.0f, 320.0f, 64.0f, " kbps", 0, 64.0f, 1.0f));
    lofi->addChild (fl (pid::codecBits, "Bit Depth", 1.0f, 24.0f, 24.0f, " bit", 1));
    lofi->addChild (ch (pid::codecFrame, "Codec Frame", choices::codecFrame, 0));
    lofi->addChild (ch (pid::codecStereo, "Codec Stereo", choices::codecStereo, 1));
    lofi->addChild (pct (pid::codecSwirl, "Swirl", 0.0f));
    lofi->addChild (bl (pid::codecDither, "Dither", false));
    lofi->addChild (pct (pid::lofiMix, "Lofi Mix", 100.0f));
    L.add (std::move (lofi));

    auto tape = std::make_unique<juce::AudioProcessorParameterGroup> ("tape", "Tape", "|");
    tape->addChild (bl (pid::tapeOn, "Tape Transport On", false));
    tape->addChild (bl (pid::hissOn, "Hiss On", false));
    tape->addChild (ch (pid::hissType, "Hiss Type", choices::hissType, 0));
    tape->addChild (fl (pid::hissLevel, "Hiss Level", -90.0f, 0.0f, -42.0f, " dB", 1));
    tape->addChild (fl (pid::hissTone, "Hiss Tone", -100.0f, 100.0f, 0.0f, "", 0));
    tape->addChild (ch (pid::hissSc, "Hiss Sidechain", choices::hissSc, 0));
    tape->addChild (pct (pid::hissScAmt, "Sidechain Amount", 100.0f));
    tape->addChild (fl (pid::hissScAtk, "Sidechain Attack", 0.1f, 200.0f, 5.0f, " ms", 1, 10.0f));
    tape->addChild (fl (pid::hissScRel, "Sidechain Release", 5.0f, 2000.0f, 150.0f, " ms", 0, 150.0f));
    tape->addChild (pct (pid::wow, "Wow", 0.0f));
    tape->addChild (pct (pid::flutter, "Flutter", 0.0f));
    tape->addChild (pct (pid::tapeDrive, "Tape Drive", 0.0f));
    L.add (std::move (tape));

    auto dyn = std::make_unique<juce::AudioProcessorParameterGroup> ("dyn", "Dynamics", "|");
    dyn->addChild (ch (pid::transMode, "Transient Mode", choices::transMode, 0));
    dyn->addChild (fl (pid::transAttack, "Transient Attack", -100.0f, 100.0f, 0.0f, " %", 0));
    dyn->addChild (fl (pid::transSustain, "Transient Sustain", -100.0f, 100.0f, 0.0f, " %", 0));
    dyn->addChild (pct (pid::transFocus, "Transient Focus", 100.0f));
    dyn->addChild (bl (pid::compOn, "Comp On", false));
    dyn->addChild (ch (pid::compStyle, "Comp Style", choices::compStyle, 0));
    dyn->addChild (fl (pid::compThresh, "Comp Threshold", -60.0f, 0.0f, -18.0f, " dB", 1, -14.0f));
    dyn->addChild (fl (pid::compRatio, "Comp Ratio", 1.0f, 20.0f, 4.0f, ":1", 1, 4.0f));
    dyn->addChild (fl (pid::compAttack, "Comp Attack", 0.05f, 200.0f, 10.0f, " ms", 2, 10.0f));
    dyn->addChild (fl (pid::compRelease, "Comp Release", 5.0f, 2000.0f, 120.0f, " ms", 0, 150.0f));
    dyn->addChild (fl (pid::compKnee, "Comp Knee", 0.0f, 24.0f, 6.0f, " dB", 1));
    dyn->addChild (fl (pid::compMakeup, "Comp Makeup", -12.0f, 24.0f, 0.0f, " dB", 1));
    dyn->addChild (pct (pid::compMix, "Comp Mix", 100.0f));
    L.add (std::move (dyn));

    auto larp = std::make_unique<juce::AudioProcessorParameterGroup> ("larp", "Larp Resampler", "|");
    larp->addChild (bl (pid::larpOn, "Larp On", false));
    larp->addChild (ch (pid::larpDiv, "Larp Slice", choices::larpDiv, 4));
    larp->addChild (ch (pid::larpHw, "Larp Hardware", choices::larpHw, 1));
    larp->addChild (fl (pid::larpGrain, "Larp Grain", 0.0f, 150.0f, 30.0f, " ms", 1, 30.0f));
    larp->addChild (pct (pid::larpSlop, "Larp Slop", 30.0f));
    larp->addChild (pct (pid::larpSmear, "Larp Smear", 30.0f));
    larp->addChild (pct (pid::larpRepeat, "Larp Repeat", 15.0f));
    larp->addChild (pct (pid::larpDeclick, "Larp Chop Dip", 40.0f));
    larp->addChild (pct (pid::larpRing, "Larp Ring", 0.0f));
    larp->addChild (fl (pid::larpRingHz, "Larp Ring Tune", 80.0f, 2000.0f, 660.0f, " Hz", 0, 500.0f));
    larp->addChild (pct (pid::larpMix, "Larp Mix", 100.0f));
    L.add (std::move (larp));

    auto outp = std::make_unique<juce::AudioProcessorParameterGroup> ("output", "Output", "|");
    outp->addChild (fl (pid::monoBelow, "Mono Below", 0.0f, 500.0f, 0.0f, " Hz", 0, 150.0f));
    outp->addChild (bl (pid::scareBoost, "Scare Boost", true));
    L.add (std::move (outp));

    for (int s = 1; s <= 2; ++s)
    {
        auto g = std::make_unique<juce::AudioProcessorParameterGroup> ("fx" + juce::String (s), "Insert FX " + juce::String (s), "|");
        const juce::String nm = "FX" + juce::String (s) + " ";
        g->addChild (bl (pid::fx (s, "On"), nm + "On", false));
        g->addChild (ch (pid::fx (s, "Type"), nm + "Type", choices::fxTypes(), s == 1 ? (int) pf::InsertFX::Stutter : (int) pf::InsertFX::Reverb));
        g->addChild (pct (pid::fx (s, "A"), nm + "A", 50.0f));
        g->addChild (pct (pid::fx (s, "B"), nm + "B", 50.0f));
        g->addChild (pct (pid::fx (s, "C"), nm + "C", 50.0f));
        g->addChild (pct (pid::fx (s, "Mix"), nm + "Mix", 100.0f));
        L.add (std::move (g));
    }
    return L;
}
