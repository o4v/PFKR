#include "PluginProcessor.h"
#include "PluginEditor.h"
#include "Presets.h"

struct ProtofukrProcessor::P
{
    explicit P (juce::AudioProcessorValueTreeState& s)
    {
        auto g = [&] (const juce::String& id) { auto* v = s.getRawParameterValue (id); jassert (v != nullptr); return v; };
        inGain = g (pid::inGain); outGain = g (pid::outGain); mix = g (pid::mix); mono = g (pid::mono); width = g (pid::width); order = g (pid::order);
        warpMode = g (pid::warpMode); warpAlgo = g (pid::warpAlgo); warpSpeed = g (pid::warpSpeed); warpPitch = g (pid::warpPitch);
        warpGrain = g (pid::warpGrain); warpFlux = g (pid::warpFlux); warpLoop = g (pid::warpLoop); warpEnv = g (pid::warpEnv);
        warpPreserve = g (pid::warpPreserve); warpLength = g (pid::warpLength); warpFreeze = g (pid::warpFreeze); warpSync = g (pid::warpSync);
        warpDir = g (pid::warpDir); warpBpm = g (pid::warpBpm); warpFreeRun = g (pid::warpFreeRun); warpMix = g (pid::warpMix);
        lofiOn = g (pid::lofiOn); codecType = g (pid::codecType); codecSR = g (pid::codecSR); codecKbps = g (pid::codecKbps);
        codecBits = g (pid::codecBits); codecFrame = g (pid::codecFrame); codecStereo = g (pid::codecStereo); codecSwirl = g (pid::codecSwirl);
        codecDither = g (pid::codecDither); lofiMix = g (pid::lofiMix);
        tapeOn = g (pid::tapeOn); hissOn = g (pid::hissOn); hissType = g (pid::hissType); hissLevel = g (pid::hissLevel); hissTone = g (pid::hissTone);
        hissSc = g (pid::hissSc); hissScAmt = g (pid::hissScAmt); hissScAtk = g (pid::hissScAtk); hissScRel = g (pid::hissScRel);
        wow = g (pid::wow); flutter = g (pid::flutter); tapeDrive = g (pid::tapeDrive);
        transMode = g (pid::transMode); transAttack = g (pid::transAttack); transSustain = g (pid::transSustain); transFocus = g (pid::transFocus);
        compOn = g (pid::compOn); compStyle = g (pid::compStyle); compThresh = g (pid::compThresh); compRatio = g (pid::compRatio);
        compAttack = g (pid::compAttack); compRelease = g (pid::compRelease); compKnee = g (pid::compKnee); compMakeup = g (pid::compMakeup); compMix = g (pid::compMix);
        larpOn = g (pid::larpOn); larpDiv = g (pid::larpDiv); larpHw = g (pid::larpHw); larpGrain = g (pid::larpGrain); larpSlop = g (pid::larpSlop);
        larpSmear = g (pid::larpSmear); larpRepeat = g (pid::larpRepeat); larpDeclick = g (pid::larpDeclick); larpRing = g (pid::larpRing);
        larpRingHz = g (pid::larpRingHz); larpMix = g (pid::larpMix); monoBelow = g (pid::monoBelow); scareBoost = g (pid::scareBoost);
        for (int s2 = 0; s2 < 2; ++s2)
        {
            fxOn[s2] = g (pid::fx (s2 + 1, "On")); fxType[s2] = g (pid::fx (s2 + 1, "Type"));
            fxA[s2] = g (pid::fx (s2 + 1, "A")); fxB[s2] = g (pid::fx (s2 + 1, "B")); fxC[s2] = g (pid::fx (s2 + 1, "C")); fxMix[s2] = g (pid::fx (s2 + 1, "Mix"));
        }
    }
    using A = std::atomic<float>*;
    A inGain, outGain, mix, mono, width, order;
    A warpMode, warpAlgo, warpSpeed, warpPitch, warpGrain, warpFlux, warpLoop, warpEnv, warpPreserve, warpLength, warpFreeze, warpSync, warpDir, warpBpm, warpFreeRun, warpMix;
    A lofiOn, codecType, codecSR, codecKbps, codecBits, codecFrame, codecStereo, codecSwirl, codecDither, lofiMix;
    A tapeOn, hissOn, hissType, hissLevel, hissTone, hissSc, hissScAmt, hissScAtk, hissScRel, wow, flutter, tapeDrive;
    A transMode, transAttack, transSustain, transFocus, compOn, compStyle, compThresh, compRatio, compAttack, compRelease, compKnee, compMakeup, compMix;
    A larpOn, larpDiv, larpHw, larpGrain, larpSlop, larpSmear, larpRepeat, larpDeclick, larpRing, larpRingHz, larpMix, monoBelow, scareBoost;
    A fxOn[2], fxType[2], fxA[2], fxB[2], fxC[2], fxMix[2];
};

static inline int ci (std::atomic<float>* a) { return (int) std::lround (a->load()); }
static inline bool cb (std::atomic<float>* a) { return a->load() > 0.5f; }

ProtofukrProcessor::ProtofukrProcessor()
    : AudioProcessor (BusesProperties()
                          .withInput ("Input", juce::AudioChannelSet::stereo(), true)
                          .withOutput ("Output", juce::AudioChannelSet::stereo(), true)
                          .withInput ("Sidechain", juce::AudioChannelSet::stereo(), false)),
      apvts (*this, nullptr, "PROTOFUKR", createParameterLayout())
{
    p = std::make_unique<P> (apvts);
    formats.registerBasicFormats();
    startTimerHz (10);
}

ProtofukrProcessor::~ProtofukrProcessor() { stopTimer(); }

bool ProtofukrProcessor::isBusesLayoutSupported (const BusesLayout& l) const
{
    const auto in = l.getMainInputChannelSet(), out = l.getMainOutputChannelSet();
    if (out != juce::AudioChannelSet::mono() && out != juce::AudioChannelSet::stereo()) return false;
    if (in != out) return false;
    if (l.inputBuses.size() > 1)
    {
        const auto sc = l.getChannelSet (true, 1);
        if (! sc.isDisabled() && sc != juce::AudioChannelSet::mono() && sc != juce::AudioChannelSet::stereo()) return false;
    }
    return true;
}

void ProtofukrProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    sr = sampleRate;
    warp.prepare (sr);
    trans.prepare (sr);
    comp.prepare (sr);
    fx[0].prepare (sr, 0x1234u); fx[1].prepare (sr, 0xBEEFu);
    tape.prepare (sr);
    codec.prepare (sr);
    larp.prepare (sr);
    for (auto& b : bassMonoHP) b.reset();
    lastMonoHz = -1.0f;
    for (auto& d : dryDelay) d.prepare ((size_t) (2 * pf::LofiCodec::kMaxM) + 16);
    inG.prepare (sr); outG.prepare (sr); mixS.prepare (sr); widthS.prepare (sr);
    inG.reset (pf::dbToGain (p->inGain->load())); outG.reset (pf::dbToGain (p->outGain->load()));
    mixS.reset (p->mix->load() * 0.01f); widthS.reset (p->width->load() * 0.01f);
    dryBuf.setSize (2, std::max (samplesPerBlock, 2048), false, true, true);
    // report current latency right away
    pf::LofiCodec::Params cp; cp.type = cb (p->lofiOn) ? ci (p->codecType) : 0; cp.frame = ci (p->codecFrame); cp.targetSR = p->codecSR->load();
    wantedLatency = codec.latencyFor (cp);
    setLatencySamples (wantedLatency.load());
}

void ProtofukrProcessor::timerCallback()
{
    const int w = wantedLatency.load();
    if (w != getLatencySamples()) setLatencySamples (w);
}

void ProtofukrProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    const int n = buffer.getNumSamples();
    auto mainIn = getBusBuffer (buffer, true, 0);
    const int nch = mainIn.getNumChannels();
    if (nch == 0 || n == 0) return;

    for (int c = getTotalNumInputChannels(); c < getTotalNumOutputChannels(); ++c) buffer.clear (c, 0, n);

    const float* scL = nullptr; const float* scR = nullptr;
    if (getBusCount (true) > 1 && getBus (true, 1)->isEnabled())
    {
        auto sc = getBusBuffer (buffer, true, 1);
        if (sc.getNumChannels() > 0) { scL = sc.getReadPointer (0); scR = sc.getNumChannels() > 1 ? sc.getReadPointer (1) : scL; }
    }

    double bpm = 120.0, ppq = 0.0; bool playing = false;
    if (auto* ph = getPlayHead())
        if (auto pos = ph->getPosition())
        {
            if (auto b = pos->getBpm()) bpm = *b;
            if (auto q = pos->getPpqPosition()) ppq = *q;
            playing = pos->getIsPlaying();
        }

    float* L = mainIn.getWritePointer (0);
    float* R = nch > 1 ? mainIn.getWritePointer (1) : nullptr;

    float pk = 0; for (int c = 0; c < nch; ++c) pk = std::max (pk, mainIn.getMagnitude (c, 0, n));
    inPeak = std::max (pk, inPeak.load() * 0.85f);

    const double spb = 60.0 / std::max (20.0, bpm) * sr;
    for (int off = 0; off < n; off += 2048)
    {
        const int len = std::min (2048, n - off);
        processChunk (L + off, R ? R + off : nullptr, scL ? scL + off : nullptr, scR ? scR + off : nullptr, len, bpm, ppq + (double) off / spb, playing);
    }

    float po = 0; for (int c = 0; c < nch; ++c) po = std::max (po, mainIn.getMagnitude (c, 0, n));
    outPeak = std::max (po, outPeak.load() * 0.85f);

    // scope (mono)
    int w = scopeWrite.load();
    for (int i = 0; i < n; ++i)
    {
        scope[w] = R ? 0.5f * (L[i] + R[i]) : L[i];
        w = (w + 1) & (kScopeSize - 1);
    }
    scopeWrite = w;
}

void ProtofukrProcessor::processChunk (float* L, float* R, const float* scL, const float* scR, int n, double bpm, double ppq, bool playing)
{
    const bool stereo = R != nullptr;
    if (dryBuf.getNumSamples() < n) return;   // never allocate on audio thread (host promised max block)

    // ---- input gain & dry copy ----
    inG.set (pf::dbToGain (p->inGain->load()));
    for (int i = 0; i < n; ++i) { const float g = inG.next(); L[i] *= g; if (stereo) R[i] *= g; }
    dryBuf.copyFrom (0, 0, L, n);
    dryBuf.copyFrom (1, 0, stereo ? R : L, n);

    // ---- warp ----
    pf::WarpEngine::Params wp;
    wp.mode = ci (p->warpMode); wp.algo = ci (p->warpAlgo); wp.speed = p->warpSpeed->load(); wp.pitch = p->warpPitch->load();
    wp.grainMs = p->warpGrain->load(); wp.flux = p->warpFlux->load() * 0.01f; wp.loopMode = ci (p->warpLoop);
    wp.envelope = p->warpEnv->load() * 0.01f; wp.preserve = ci (p->warpPreserve);
    wp.captureBeats = choices::warpLengthBeats[juce::jlimit (0, 6, ci (p->warpLength))];
    wp.freeze = cb (p->warpFreeze); wp.sync = cb (p->warpSync); wp.direction = ci (p->warpDir); wp.sampleBpm = p->warpBpm->load();
    wp.freeRun = cb (p->warpFreeRun); wp.mix = p->warpMix->load() * 0.01f;
    {
        const juce::SpinLock::ScopedTryLockType tl (sampleLock);
        if (tl.isLocked()) warp.process (L, R, n, wp, bpm, ppq, playing);
    }
    warpPlayhead = warp.playheadNorm.load();

    // ---- larp resampler (qaeru mode)
    pf::LarpResampler::Params rp;
    rp.on = cb (p->larpOn); rp.division = ci (p->larpDiv); rp.hardware = ci (p->larpHw); rp.grainMs = p->larpGrain->load();
    rp.slop = p->larpSlop->load() * 0.01f; rp.smear = p->larpSmear->load() * 0.01f; rp.repeat = p->larpRepeat->load() * 0.01f;
    rp.declick = p->larpDeclick->load() * 0.01f; rp.ring = p->larpRing->load() * 0.01f; rp.ringHz = p->larpRingHz->load();
    rp.mix = p->larpMix->load() * 0.01f;
    larp.process (L, R, n, rp, bpm, ppq, playing);

    // ---- dynamics ----
    pf::TransientShaper::Params tp { ci (p->transMode), p->transAttack->load() * 0.01f, p->transSustain->load() * 0.01f, p->transFocus->load() * 0.01f };
    trans.process (L, R, n, tp);
    pf::Compressor::Params cp;
    cp.on = cb (p->compOn); cp.style = ci (p->compStyle); cp.thresholdDb = p->compThresh->load(); cp.ratio = p->compRatio->load();
    cp.attackMs = p->compAttack->load(); cp.releaseMs = p->compRelease->load(); cp.kneeDb = p->compKnee->load();
    cp.makeupDb = p->compMakeup->load(); cp.mix = p->compMix->load() * 0.01f;
    comp.process (L, R, n, cp);
    compGr = comp.gr.load();

    // ---- insert FX ----
    pf::HostTime ht { bpm, ppq, playing };
    for (int s = 0; s < 2; ++s)
    {
        pf::InsertFX::Params fp;
        fp.on = cb (p->fxOn[s]); fp.type = ci (p->fxType[s]);
        fp.a = p->fxA[s]->load() * 0.01f; fp.b = p->fxB[s]->load() * 0.01f; fp.c = p->fxC[s]->load() * 0.01f; fp.mix = p->fxMix[s]->load() * 0.01f;
        fx[s].process (L, R, n, fp, ht);
    }

    // ---- tape + codec (order selectable) ----
    pf::TapeSection::Params tpp;
    const bool tapeTransport = cb (p->tapeOn);
    tpp.hissOn = cb (p->hissOn); tpp.hissType = ci (p->hissType); tpp.hissDb = p->hissLevel->load(); tpp.tone = p->hissTone->load() * 0.01f;
    tpp.scSource = ci (p->hissSc); tpp.scAmount = p->hissScAmt->load() * 0.01f; tpp.scAttackMs = p->hissScAtk->load(); tpp.scReleaseMs = p->hissScRel->load();
    tpp.wow = tapeTransport ? p->wow->load() * 0.01f : 0.0f; tpp.flutter = tapeTransport ? p->flutter->load() * 0.01f : 0.0f;
    tpp.drive = tapeTransport ? p->tapeDrive->load() * 0.01f : 0.0f;

    pf::LofiCodec::Params lp;
    lp.type = cb (p->lofiOn) ? ci (p->codecType) : (int) pf::LofiCodec::Clean;
    lp.targetSR = p->codecSR->load(); lp.kbps = p->codecKbps->load();
    lp.bits = cb (p->lofiOn) ? p->codecBits->load() : 24.0f;
    lp.frame = ci (p->codecFrame); lp.stereo = ci (p->codecStereo); lp.swirl = p->codecSwirl->load() * 0.01f;
    lp.dither = cb (p->codecDither); lp.mix = p->lofiMix->load() * 0.01f;
    wantedLatency = codec.latencyFor (lp);

    if (ci (p->order) == 0) { tape.process (L, R, scL, scR, n, tpp); codec.process (L, R, n, lp); }
    else                    { codec.process (L, R, n, lp); tape.process (L, R, scL, scR, n, tpp); }
    codecHop = codec.currentLatency();
    codecBandwidth = codec.currentBandwidthHz();

    // ---- stereo / mono / width / output / global mix ----
    const bool mono = cb (p->mono);
    const int lat = codec.currentLatency();
    outG.set (pf::dbToGain (p->outGain->load()));
    mixS.set (p->mix->load() * 0.01f);
    widthS.set (p->width->load() * 0.01f);
    const float monoHz = p->monoBelow->load();
    const bool bassMono = monoHz >= 20.0f && stereo && ! mono;
    if (bassMono && std::abs (monoHz - lastMonoHz) > 0.5f)
    {
        bassMonoHP[0].set (pf::Biquad::HP, sr, monoHz, 0.54f); bassMonoHP[1].set (pf::Biquad::HP, sr, monoHz, 1.31f);
        lastMonoHz = monoHz;
    }
    const float* dL = dryBuf.getReadPointer (0);
    const float* dR = dryBuf.getReadPointer (1);
    for (int i = 0; i < n; ++i)
    {
        float l = L[i], r = stereo ? R[i] : l;
        const float wdt = widthS.next();
        float m = 0.5f * (l + r), s = 0.5f * (l - r) * (mono ? 0.0f : wdt);
        if (bassMono) s = bassMonoHP[1].process (bassMonoHP[0].process (s));   // lows mono, highs keep their width
        l = m + s; r = m - s;
        const float og = outG.next(), mx = mixS.next();
        dryDelay[0].push (dL[i]); dryDelay[1].push (dR[i]);
        const float dl = dryDelay[0].readInt ((uint32_t) lat + 1), dr = dryDelay[1].readInt ((uint32_t) lat + 1);
        L[i] = pf::sanitize ((mx * l + (1.0f - mx) * dl) * og);
        if (stereo) R[i] = pf::sanitize ((mx * r + (1.0f - mx) * dr) * og);
    }

    // ---- qaeru jumpscare boost: +30 dB into a hard 0 dBFS ceiling for 0.3 s (can never exceed digital full scale)
    int sd = scareDelay.load();
    if (sd >= 0)
    {
        if (sd <= n) { scareDelay = -1; if (cb (p->scareBoost)) { scareTotal = (int) (sr * 0.3); scareRemain = scareTotal; } }
        else scareDelay = sd - n;
    }
    if (scareRemain > 0)
    {
        const float fadeLen = (float) (sr * 0.004);
        for (int i = 0; i < n && scareRemain > 0; ++i, --scareRemain)
        {
            const float pos = (float) (scareTotal - scareRemain);
            const float env = std::min ({ 1.0f, pos / fadeLen, (float) scareRemain / fadeLen });
            const float g = 1.0f + env * 30.6f;                       // up to +30 dB
            L[i] = pf::clampf (L[i] * g, -1.0f, 1.0f);
            if (stereo) R[i] = pf::clampf (R[i] * g, -1.0f, 1.0f);
        }
    }
}

// ------------------------------------------------------------------ presets / programs
int ProtofukrProcessor::getNumPrograms() { return (int) factoryPresets().size(); }
const juce::String ProtofukrProcessor::getProgramName (int i)
{
    const auto& ps = factoryPresets();
    return juce::isPositiveAndBelow (i, (int) ps.size()) ? juce::String (ps[(size_t) i].name) : juce::String();
}
void ProtofukrProcessor::setCurrentProgram (int i)
{
    if (! juce::isPositiveAndBelow (i, getNumPrograms())) return;
    currentProgram = i;
    if (juce::MessageManager::getInstanceWithoutCreating() != nullptr && juce::MessageManager::getInstance()->isThisTheMessageThread())
        applyPreset (i);
    else
        juce::MessageManager::callAsync ([this, i, w = std::weak_ptr<bool> (alive)] { if (! w.expired()) applyPreset (i); });
}

void ProtofukrProcessor::setParam (const juce::String& id, float realValue)
{
    if (auto* prm = apvts.getParameter (id))
    {
        const float norm = prm->convertTo0to1 (realValue);
        prm->beginChangeGesture();
        prm->setValueNotifyingHost (norm);
        prm->endChangeGesture();
    }
}

void ProtofukrProcessor::applyPreset (int index)
{
    const auto& ps = factoryPresets();
    if (! juce::isPositiveAndBelow (index, (int) ps.size())) return;
    currentProgram = index;
    // reset everything to defaults first (except sample BPM which belongs to the loaded file)
    for (auto* prm : getParameters())
        if (auto* rp = dynamic_cast<juce::RangedAudioParameter*> (prm))
            if (rp->getParameterID() != pid::warpBpm)
            {
                rp->beginChangeGesture(); rp->setValueNotifyingHost (rp->getDefaultValue()); rp->endChangeGesture();
            }
    for (const auto& kv : ps[(size_t) index].values) setParam (kv.first, kv.second);
}

// ------------------------------------------------------------------ sample loading
bool ProtofukrProcessor::loadSample (const juce::File& f)
{
    std::unique_ptr<juce::AudioFormatReader> reader (formats.createReaderFor (f));
    if (reader == nullptr) return false;
    const auto maxLen = (juce::int64) (reader->sampleRate * 600.0);          // 10 minutes max
    const int len = (int) std::min (reader->lengthInSamples, maxLen);
    if (len < 64) return false;
    auto data = std::make_shared<pf::SampleData>();
    const int nc = (int) std::min (2u, reader->numChannels);
    data->audio.setSize (nc, len);
    reader->read (&data->audio, 0, len, 0, true, nc > 1);
    data->fileRate = reader->sampleRate;
    data->name = f.getFileNameWithoutExtension();
    pf::WarpEngine::analyseSample (*data);
    {
        const juce::SpinLock::ScopedLockType sl (sampleLock);
        warp.setSample (data);
    }
    samplePath = f.getFullPathName();
    setParam (pid::warpBpm, (float) data->estimatedBpm);
    return true;
}

void ProtofukrProcessor::triggerScareBoost (double delaySec)
{
    scareDelay = (int) std::max (0.0, delaySec * sr);
}

juce::String ProtofukrProcessor::getSampleName() const
{
    auto s = warp.getSample();
    return s ? s->name : juce::String();
}

std::vector<float> ProtofukrProcessor::getSamplePeaks() const
{
    auto s = warp.getSample();
    return s ? s->peaks : std::vector<float>();
}

// ------------------------------------------------------------------ state
void ProtofukrProcessor::getStateInformation (juce::MemoryBlock& dest)
{
    auto state = apvts.copyState();
    state.setProperty ("samplePath", samplePath, nullptr);
    state.setProperty ("program", currentProgram, nullptr);
    state.setProperty ("uiScale", uiScale.load(), nullptr);
    if (auto xml = state.createXml()) copyXmlToBinary (*xml, dest);
}

void ProtofukrProcessor::setStateInformation (const void* data, int size)
{
    if (auto xml = getXmlFromBinary (data, size))
        if (xml->hasTagName (apvts.state.getType()))
        {
            auto vt = juce::ValueTree::fromXml (*xml);
            const juce::String path = vt.getProperty ("samplePath").toString();
            currentProgram = (int) vt.getProperty ("program", 0);
            uiScale = (float) (double) vt.getProperty ("uiScale", 1.0);
            const float bpmSaved = (float) vt.getChildWithProperty ("id", pid::warpBpm).getProperty ("value", 120.0);
            apvts.replaceState (vt);
            if (path.isNotEmpty())
                juce::MessageManager::callAsync ([this, path, bpmSaved, w = std::weak_ptr<bool> (alive)]
                {
                    if (w.expired()) return;
                    juce::File f (path);
                    if (f.existsAsFile() && loadSample (f)) setParam (pid::warpBpm, bpmSaved);   // keep the user's BPM
                });
        }
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new ProtofukrProcessor(); }
