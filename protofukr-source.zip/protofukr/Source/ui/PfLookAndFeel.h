#pragma once
#include "Theme.h"

class PfLookAndFeel : public juce::LookAndFeel_V4
{
public:
    PfLookAndFeel()
    {
        setColour (juce::ComboBox::backgroundColourId, theme::chassisLight);
        setColour (juce::ComboBox::textColourId, theme::ink);
        setColour (juce::ComboBox::outlineColourId, theme::chassisDark);
        setColour (juce::ComboBox::arrowColourId, theme::hot);
        setColour (juce::PopupMenu::backgroundColourId, theme::chassisLight);
        setColour (juce::PopupMenu::textColourId, theme::ink);
        setColour (juce::PopupMenu::highlightedBackgroundColourId, theme::pink);
        setColour (juce::PopupMenu::highlightedTextColourId, theme::ink);
        setColour (juce::PopupMenu::headerTextColourId, theme::hot);
        setColour (juce::Label::textColourId, theme::ink);
        setColour (juce::TextEditor::backgroundColourId, juce::Colours::white);
        setColour (juce::TextEditor::textColourId, theme::ink);
        setColour (juce::TextEditor::highlightColourId, theme::pink);
        setColour (juce::TextEditor::focusedOutlineColourId, theme::hot);
        setColour (juce::CaretComponent::caretColourId, theme::hot);
        setColour (juce::TextButton::textColourOffId, theme::ink);
        setColour (juce::TextButton::textColourOnId, theme::ink);
        setColour (juce::Slider::textBoxTextColourId, juce::Colours::white);
        setColour (juce::Slider::textBoxBackgroundColourId, theme::hot);
        setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
        setColour (juce::Slider::textBoxHighlightColourId, theme::pink);
        setColour (juce::TooltipWindow::backgroundColourId, theme::ink);
        setColour (juce::TooltipWindow::textColourId, juce::Colours::white);
    }

    // ---------------------------------------------------------------- knobs
    void drawRotarySlider (juce::Graphics& g, int x, int y, int w, int h, float pos, float a0, float a1, juce::Slider& s) override
    {
        auto r = juce::Rectangle<float> ((float) x, (float) y, (float) w, (float) h).reduced (3.0f);
        const float d = std::min (r.getWidth(), r.getHeight());
        r = r.withSizeKeepingCentre (d, d);
        const auto c = r.getCentre();
        const auto accent = s.findColour (juce::Slider::rotarySliderFillColourId);
        const float ang = a0 + pos * (a1 - a0);

        // track
        juce::Path track; track.addCentredArc (c.x, c.y, d * 0.5f - 2.0f, d * 0.5f - 2.0f, 0, a0, a1, true);
        g.setColour (theme::groove.withAlpha (0.55f));
        g.strokePath (track, juce::PathStrokeType (3.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        const bool bipolar = s.getMinimum() < 0.0 && s.getMaximum() > 0.0;
        const float from = bipolar ? a0 + (float) s.valueToProportionOfLength (0.0) * (a1 - a0) : a0;
        juce::Path val; val.addCentredArc (c.x, c.y, d * 0.5f - 2.0f, d * 0.5f - 2.0f, 0, std::min (from, ang), std::max (from, ang), true);
        g.setColour (accent.darker (0.35f));
        g.strokePath (val, juce::PathStrokeType (3.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        // candy body
        const float br = d * 0.36f;
        auto body = juce::Rectangle<float> (br * 2, br * 2).withCentre (c);
        g.setColour (juce::Colours::black.withAlpha (0.22f));
        g.fillEllipse (body.translated (0, 2.0f).expanded (1.0f));
        juce::ColourGradient grad (accent.brighter (0.45f), c.x - br * 0.4f, c.y - br * 0.6f, accent.darker (0.35f), c.x + br * 0.5f, c.y + br, true);
        g.setGradientFill (grad);
        g.fillEllipse (body);
        g.setColour (accent.darker (0.7f));
        g.drawEllipse (body, 1.0f);
        // specular highlight
        auto spec = juce::Rectangle<float> (br * 1.25f, br * 0.75f).withCentre ({ c.x - br * 0.18f, c.y - br * 0.48f });
        g.setGradientFill (juce::ColourGradient (juce::Colours::white.withAlpha (0.85f), spec.getCentreX(), spec.getY(),
                                                 juce::Colours::white.withAlpha (0.0f), spec.getCentreX(), spec.getBottom(), false));
        g.fillEllipse (spec);
        // pointer
        juce::Path ptr; ptr.addRoundedRectangle (-1.6f, -br * 0.95f, 3.2f, br * 0.55f, 1.6f);
        g.setColour (theme::ink);
        g.fillPath (ptr, juce::AffineTransform::rotation (ang).translated (c.x, c.y));
    }

    // ---------------------------------------------------------------- vertical faders (Grain-Strain-ish)
    void drawLinearSlider (juce::Graphics& g, int x, int y, int w, int h, float pos, float, float, juce::Slider::SliderStyle st, juce::Slider& s) override
    {
        if (st != juce::Slider::LinearVertical) { LookAndFeel_V4::drawLinearSlider (g, x, y, w, h, pos, 0, 0, st, s); return; }
        const auto accent = s.findColour (juce::Slider::rotarySliderFillColourId);
        auto r = juce::Rectangle<float> ((float) x, (float) y, (float) w, (float) h);
        const float cx = r.getCentreX();
        // ticks
        g.setColour (theme::inkSoft.withAlpha (0.7f));
        for (int i = 0; i <= 10; ++i)
        {
            const float ty = r.getY() + 6.0f + (r.getHeight() - 12.0f) * (float) i / 10.0f;
            const float len = (i % 5 == 0) ? 9.0f : 5.0f;
            g.drawLine (cx - 15.0f - len, ty, cx - 15.0f, ty, 1.0f);
            g.drawLine (cx + 15.0f, ty, cx + 15.0f + len, ty, 1.0f);
        }
        // groove
        auto gr = juce::Rectangle<float> (cx - 3.0f, r.getY() + 2.0f, 6.0f, r.getHeight() - 4.0f);
        g.setColour (theme::groove);
        g.fillRoundedRectangle (gr, 3.0f);
        g.setColour (juce::Colours::white.withAlpha (0.4f));
        g.drawLine (gr.getRight() + 0.5f, gr.getY() + 3, gr.getRight() + 0.5f, gr.getBottom() - 3, 1.0f);
        // fill below cap
        g.setColour (accent.withAlpha (0.8f));
        g.fillRoundedRectangle (gr.withTop (pos).reduced (1.0f, 0.0f), 2.0f);
        // cap
        auto cap = juce::Rectangle<float> (30.0f, 16.0f).withCentre ({ cx, pos });
        g.setColour (juce::Colours::black.withAlpha (0.25f));
        g.fillRoundedRectangle (cap.translated (0, 2), 4.0f);
        theme::glossFill (g, cap, theme::chassisLight, 4.0f);
        g.setColour (accent.darker (0.4f));
        g.fillRect (cap.withSizeKeepingCentre (cap.getWidth() - 8.0f, 2.0f));
    }

    juce::Slider::SliderLayout getSliderLayout (juce::Slider& s) override
    {
        auto l = LookAndFeel_V4::getSliderLayout (s);
        if (s.getSliderStyle() == juce::Slider::LinearVertical)
        {
            auto b = s.getLocalBounds();
            l.textBoxBounds = b.removeFromTop (20).reduced (2, 0);
            b.removeFromTop (6);
            l.sliderBounds = b.reduced (0, 6);
        }
        return l;
    }

    juce::Label* createSliderTextBox (juce::Slider& s) override
    {
        auto* l = LookAndFeel_V4::createSliderTextBox (s);
        const bool lcdStyle = s.getSliderStyle() == juce::Slider::LinearVertical || s.getSliderStyle() == juce::Slider::LinearBar;
        l->setFont (theme::lcd (lcdStyle ? 19.0f : 17.0f));
        l->setColour (juce::Label::textColourId, lcdStyle ? theme::lcdInk : juce::Colours::white);
        l->setColour (juce::Label::backgroundColourId, lcdStyle ? theme::lcdBg : theme::hot);
        l->setColour (juce::Label::outlineColourId, juce::Colours::transparentBlack);
        l->setColour (juce::TextEditor::backgroundColourId, juce::Colours::white);
        l->setColour (juce::TextEditor::textColourId, theme::ink);
        l->setJustificationType (juce::Justification::centred);
        l->setMinimumHorizontalScale (0.6f);
        l->getProperties().set ("pill", true);
        l->getProperties().set ("lcd", lcdStyle);
        return l;
    }

    void drawLabel (juce::Graphics& g, juce::Label& l) override
    {
        if (l.getProperties()["pill"])
        {
            auto r = l.getLocalBounds().toFloat().reduced (0.5f);
            const bool lcdStyle = l.getProperties()["lcd"];
            if (lcdStyle)
            {
                g.setColour (theme::lcdBg); g.fillRoundedRectangle (r, 3.0f);
                g.setColour (theme::groove); g.drawRoundedRectangle (r, 3.0f, 1.2f);
                g.setColour (juce::Colours::black.withAlpha (0.08f)); g.fillRect (r.withHeight (3.0f).translated (0, 1));
            }
            else
            {
                g.setColour (theme::hot); g.fillRoundedRectangle (r, r.getHeight() * 0.5f);
                g.setColour (juce::Colours::white.withAlpha (0.25f)); g.fillRoundedRectangle (r.withHeight (r.getHeight() * 0.45f).reduced (3, 1), r.getHeight() * 0.25f);
            }
            if (! l.isBeingEdited())
            {
                g.setColour (l.findColour (juce::Label::textColourId));
                g.setFont (l.getFont());
                g.drawFittedText (l.getText(), l.getLocalBounds().reduced (3, 0), juce::Justification::centred, 1, 0.6f);
            }
            return;
        }
        LookAndFeel_V4::drawLabel (g, l);
    }

    // ---------------------------------------------------------------- buttons
    void drawButtonBackground (juce::Graphics& g, juce::Button& b, const juce::Colour&, bool over, bool down) override
    {
        auto r = b.getLocalBounds().toFloat().reduced (1.0f);
        const bool on = b.getToggleState();
        auto base = on ? b.findColour (juce::TextButton::buttonOnColourId) : theme::chassisLight;
        if (over) base = base.brighter (0.08f);
        if (down) base = base.darker (0.1f);
        theme::glossFill (g, r, base, std::min (8.0f, r.getHeight() * 0.5f));
    }

    juce::Font getTextButtonFont (juce::TextButton&, int h) override { return theme::label (std::min (13.0f, (float) h * 0.6f)); }

    void drawToggleButton (juce::Graphics& g, juce::ToggleButton& b, bool over, bool) override
    {
        // jelly LED + label
        auto r = b.getLocalBounds().toFloat();
        const bool on = b.getToggleState();
        auto led = juce::Rectangle<float> (14.0f, 14.0f).withCentre ({ r.getX() + 9.0f, r.getCentreY() });
        auto col = on ? b.findColour (juce::ToggleButton::tickColourId) : theme::chassisDark;
        if (on)
        {
            g.setColour (col.withAlpha (0.35f));
            g.fillEllipse (led.expanded (4.0f));
        }
        g.setGradientFill (juce::ColourGradient (col.brighter (0.6f), led.getCentreX(), led.getY(), col.darker (0.3f), led.getCentreX(), led.getBottom(), false));
        g.fillEllipse (led);
        g.setColour (juce::Colours::white.withAlpha (0.7f));
        g.fillEllipse (led.withSizeKeepingCentre (6.0f, 3.5f).translated (0, -3.0f));
        g.setColour (theme::ink.withAlpha (over ? 1.0f : 0.85f));
        g.drawEllipse (led, 1.0f);
        g.setFont (theme::label (12.0f));
        g.drawText (b.getButtonText(), r.withTrimmedLeft (20.0f), juce::Justification::centredLeft);
    }

    // ---------------------------------------------------------------- combo boxes
    void drawComboBox (juce::Graphics& g, int w, int h, bool, int, int, int, int, juce::ComboBox& cb) override
    {
        auto r = juce::Rectangle<float> (0, 0, (float) w, (float) h).reduced (0.5f);
        theme::glossFill (g, r, theme::chassisLight, h * 0.5f);
        juce::Path arrow;
        const float ax = (float) w - 14.0f, ay = (float) h * 0.5f;
        arrow.addTriangle (ax - 4.0f, ay - 2.0f, ax + 4.0f, ay - 2.0f, ax, ay + 3.0f);
        g.setColour (cb.findColour (juce::ComboBox::arrowColourId));
        g.fillPath (arrow);
    }
    juce::Font getComboBoxFont (juce::ComboBox&) override { return theme::label (12.5f); }
    void positionComboBoxText (juce::ComboBox& cb, juce::Label& l) override
    {
        l.setBounds (8, 1, cb.getWidth() - 26, cb.getHeight() - 2);
        l.setFont (getComboBoxFont (cb));
    }
    juce::Font getPopupMenuFont() override { return theme::label (13.0f); }
};
