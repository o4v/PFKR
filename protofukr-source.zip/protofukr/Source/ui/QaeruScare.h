#pragma once
// protofukr — the "qaeru" easter egg. Typing q-a-e-r-u while the window has focus peels the panel
// back from the top-right corner; a lanky pale frog-thing (an original character) climbs out of the
// darkness behind the UI, waves, and slinks back as the panel folds shut again.
// Drawn entirely with paths in a wobbly, hand-drawn "line boil" style — no image assets.
#include "Theme.h"

class QaeruScare : public juce::Component, private juce::Timer
{
public:
    QaeruScare() { setInterceptsMouseClicks (false, false); setVisible (false); }

    bool isRunning() const { return isTimerRunning(); }
    float debugTime = -1.0f;    // tests only: freeze the animation clock at a given time

    void start (juce::Image snapshot)
    {
        snap = std::move (snapshot);
        startMs = juce::Time::getMillisecondCounterHiRes();
        setInterceptsMouseClicks (true, true);      // swallow clicks while it plays
        setVisible (true);
        toFront (false);
        startTimerHz (60);
    }

    void paint (juce::Graphics& g) override
    {
        if (! snap.isValid()) return;
        const float t = elapsed();
        const float W = (float) getWidth(), H = (float) getHeight();

        // camera shake when it lunges
        if (t > 0.95f && t < 1.25f)
        {
            juce::Random r ((juce::int64) (t * 1000));
            g.addTransform (juce::AffineTransform::translation (r.nextFloat() * 8 - 4, r.nextFloat() * 8 - 4));
        }

        // -------- intro glitch
        if (t < 0.16f)
        {
            g.drawImageAt (snap, 0, 0);
            juce::Random r ((juce::int64) (t * 997.0f));
            for (int i = 0; i < 9; ++i)
            {
                const int y = r.nextInt (juce::jmax (1, (int) H - 40)), h = 6 + r.nextInt (34), dx = r.nextInt (40) - 20;
                g.saveState();
                g.reduceClipRegion (0, y, (int) W, h);
                g.drawImageAt (snap, dx, 0);
                g.setColour ((i & 1 ? juce::Colour (0xffff3e8a) : juce::Colour (0xff3ef0ff)).withAlpha (0.25f));
                g.fillRect (0, y, (int) W, h);
                g.restoreState();
            }
            return;
        }

        // -------- peel geometry
        const float peel = peelAmount (t);
        const juce::Point<float> C (W, 0.0f);
        const juce::Point<float> u = norm ({ -1.0f, 0.8f });
        const float sMax = (std::abs (u.x) * W + std::abs (u.y) * H) * 0.6f;
        const float s = peel * sMax;
        const juce::Point<float> P0 = C + u * s;
        juce::Path peeled = halfPlaneClip ({ 0, 0, W, H }, C, u, s);
        const auto refl = reflection (P0, { -u.y, u.x });

        g.drawImageAt (snap, 0, 0);
        if (s < 1.0f) return;

        // -------- the dark behind the panel
        g.saveState();
        g.reduceClipRegion (peeled);
        g.fillAll (juce::Colour (0xff050407));
        {
            juce::Random r ((juce::int64) (t * 24.0f));
            g.setColour (juce::Colour (0xff3a0f22).withAlpha (0.35f));
            for (int i = 0; i < 160; ++i) g.fillRect (r.nextFloat() * W, r.nextFloat() * H, 1.5f, 1.5f);
            juce::ColourGradient glow (juce::Colour (0x553b0d24), C.x, C.y, juce::Colours::transparentBlack, P0.x, P0.y, true);
            g.setGradientFill (glow); g.fillAll();
        }
        // monster inside the hole: sits in the dark triangle (legs a along the top, b down the right edge)
        const float aFull = std::min (W, sMax / std::abs (u.x)), bFull = std::min (H, sMax / u.y);
        const float size = juce::jlimit (110.0f, 360.0f, std::min (aFull, bFull) * 0.62f);
        const float rise = emerge (t);
        if (rise > 0.0f)
        {
            juce::Point<float> anchor (W - aFull * 0.42f, bFull * 0.36f);
            anchor.y += (1.0f - rise) * size * 1.6f;
            const float wave = (t > 1.35f && t < 2.75f) ? std::sin ((t - 1.35f) * 9.0f) : 0.0f;
            const float blink = blinkAmount (t);
            drawQaeru (g, anchor, size, wave, blink, (int) (t * 9.0f), t);
            bubbleAt = anchor; bubbleSize = size;
        }
        g.restoreState();

        // -------- the flap: the panel's back, curled up into a band next to the fold
        const float curl = std::min (s * 0.9f, 190.0f);
        juce::Path flap = peeled; flap.applyTransform (refl);
        juce::Path band = halfPlaneClip ({ -10.0f, -10.0f, W + 20.0f, H + 20.0f }, C, u, s + curl);
        {
            juce::Path sh = halfPlaneClip ({ -10.0f, -10.0f, W + 20.0f, H + 20.0f }, C, u, s + curl + 14.0f);
            g.saveState();
            g.reduceClipRegion (sh);
            g.reduceClipRegion (halfPlaneClip ({ -10.0f, -10.0f, W + 20.0f, H + 20.0f }, C, -u, -s));   // only on the panel side
            const juce::Point<float> e0 = P0 - u * curl, e1 = P0 - u * (curl + 14.0f);
            g.setGradientFill (juce::ColourGradient (juce::Colours::black.withAlpha (0.45f), e0.x, e0.y, juce::Colours::transparentBlack, e1.x, e1.y, false));
            g.fillAll();
            g.restoreState();
        }
        g.saveState();
        g.reduceClipRegion (flap);
        g.reduceClipRegion (band);
        const juce::Point<float> farEdge = P0 - u * curl;
        juce::ColourGradient paper (theme::chassisLight.brighter (0.2f), P0.x, P0.y, theme::chassisDark.darker (0.3f), farEdge.x, farEdge.y, false);
        paper.addColour (0.55, theme::chassis);
        g.setGradientFill (paper);
        g.fillAll();
        g.setOpacity (0.13f);
        g.drawImageTransformed (snap, refl);
        g.setOpacity (1.0f);
        // crease highlight
        const juce::Point<float> v (-u.y, u.x);
        g.setColour (juce::Colours::white.withAlpha (0.7f));
        g.drawLine ({ P0 - v * 2000.0f, P0 + v * 2000.0f }, 2.0f);
        g.restoreState();

        // speech bubble: "qaeru was here", typed out while he waves
        if (t > 1.2f && t < 2.95f)
        {
            const juce::String msg ("qaeru was here");
            const int shown = juce::jlimit (0, msg.length(), (int) ((t - 1.2f) * 22.0f));
            const float S = bubbleSize;
            const float pop = juce::jlimit (0.0f, 1.0f, (t - 1.2f) * 8.0f) * juce::jlimit (0.0f, 1.0f, (2.95f - t) * 8.0f);
            auto font = theme::header (juce::jlimit (18.0f, 34.0f, S * 0.085f));
            const float tw = juce::GlyphArrangement::getStringWidth (font, msg) + 36.0f, th = font.getHeight() + 26.0f;
            juce::Rectangle<float> box (bubbleAt.x - S * 0.55f - tw, bubbleAt.y - S * 0.62f - th * 0.5f, tw, th);
            box.setX (std::max (8.0f, box.getX()));
            box = box.withSizeKeepingCentre (box.getWidth() * (0.6f + 0.4f * pop), box.getHeight() * (0.6f + 0.4f * pop));
            juce::Random r ((juce::int64) (t * 9.0f));
            juce::Path bub;
            bub.addRoundedRectangle (box.translated (r.nextFloat() * 1.5f, r.nextFloat() * 1.5f), th * 0.45f);
            // tail pointing at his mouth
            const juce::Point<float> tip (bubbleAt.x - S * 0.38f, bubbleAt.y - S * 0.05f);
            juce::Path tail;
            tail.addTriangle (box.getRight() - th * 0.9f, box.getBottom() - 4.0f, box.getRight() - th * 0.35f, box.getBottom() - 4.0f, tip.x, tip.y);
            g.setOpacity (pop);
            g.setColour (juce::Colours::white);
            g.fillPath (bub); g.fillPath (tail);
            g.setColour (juce::Colours::black);
            g.strokePath (bub, juce::PathStrokeType (3.0f));
            g.strokePath (tail, juce::PathStrokeType (3.0f));
            g.setColour (juce::Colours::white);
            g.fillRect (juce::Rectangle<float> (box.getRight() - th * 0.9f + 2.0f, box.getBottom() - 6.0f, th * 0.55f - 4.0f, 5.0f));
            g.setColour (juce::Colour (0xff2a060f));
            g.setFont (font);
            g.drawText (msg.substring (0, shown), box, juce::Justification::centred);
        }
    }

private:
    static constexpr float kTotal = 4.3f;
    juce::Image snap;
    juce::Point<float> bubbleAt; float bubbleSize = 200.0f;
    double startMs = 0;

    float elapsed() const { return debugTime >= 0.0f ? debugTime : (float) ((juce::Time::getMillisecondCounterHiRes() - startMs) * 0.001); }

    void timerCallback() override
    {
        if (elapsed() > kTotal)
        {
            stopTimer(); setVisible (false); setInterceptsMouseClicks (false, false); snap = {};
            return;
        }
        repaint();
    }

    static float ease (float x) { x = juce::jlimit (0.0f, 1.0f, x); return x * x * (3.0f - 2.0f * x); }
    static float easeOutBack (float x)
    {
        x = juce::jlimit (0.0f, 1.0f, x);
        const float c1 = 1.9f, c3 = c1 + 1.0f;
        return 1.0f + c3 * std::pow (x - 1.0f, 3.0f) + c1 * std::pow (x - 1.0f, 2.0f);
    }
    static float peelAmount (float t)
    {
        if (t < 0.16f) return 0.0f;
        if (t < 0.9f) return ease ((t - 0.16f) / 0.74f);
        if (t < 3.45f) return 1.0f;
        return 1.0f - ease ((t - 3.45f) / 0.75f);
    }
    static float emerge (float t)
    {
        if (t < 0.6f) return 0.0f;
        if (t < 1.25f) return easeOutBack ((t - 0.6f) / 0.65f);
        if (t < 2.8f) return 1.0f;
        return 1.0f - ease ((t - 2.8f) / 0.6f);
    }
    static float blinkAmount (float t)
    {
        auto b = [] (float t0, float x) { const float d = std::abs (x - t0); return d < 0.09f ? 1.0f - d / 0.09f : 0.0f; };
        return std::max ({ b (1.55f, t), b (2.35f, t), t > 2.95f ? juce::jlimit (0.0f, 1.0f, (t - 2.95f) * 4.0f) : 0.0f });
    }

    static juce::Point<float> norm (juce::Point<float> p) { const float l = std::hypot (p.x, p.y); return { p.x / l, p.y / l }; }

    // polygon = rect ∩ { X : dot(X - C, u) < s }
    static juce::Path halfPlaneClip (juce::Rectangle<float> r, juce::Point<float> C, juce::Point<float> u, float s)
    {
        juce::Point<float> pts[4] = { r.getTopLeft(), r.getTopRight(), r.getBottomRight(), r.getBottomLeft() };
        juce::Array<juce::Point<float>> out;
        auto f = [&] (juce::Point<float> p) { return (p - C).getDotProduct (u) - s; };
        for (int i = 0; i < 4; ++i)
        {
            const auto a = pts[i], b = pts[(i + 1) % 4];
            const float fa = f (a), fb = f (b);
            if (fa < 0) out.add (a);
            if ((fa < 0) != (fb < 0)) out.add (a + (b - a) * (fa / (fa - fb)));
        }
        juce::Path p;
        for (int i = 0; i < out.size(); ++i) { if (i == 0) p.startNewSubPath (out[i]); else p.lineTo (out[i]); }
        p.closeSubPath();
        return p;
    }

    static juce::AffineTransform reflection (juce::Point<float> P0, juce::Point<float> v)
    {
        const float a = v.x * v.x - v.y * v.y, b = 2.0f * v.x * v.y, d = v.y * v.y - v.x * v.x;
        return juce::AffineTransform (a, b, P0.x - (a * P0.x + b * P0.y),
                                      b, d, P0.y - (b * P0.x + d * P0.y));
    }

    // deterministic hash noise for the line boil
    static float jitter (int seed, int i) { juce::Random r ((juce::int64) (seed * 7919 + i * 104729)); return r.nextFloat() * 2.0f - 1.0f; }

    static juce::Path blob (juce::Point<float> c, float rx, float ry, int n, float wob, int seed, float lumpFreq = 3.0f)
    {
        juce::Path p;
        for (int i = 0; i <= n; ++i)
        {
            const float a = juce::MathConstants<float>::twoPi * (float) (i % n) / (float) n;
            const float lump = 1.0f + 0.05f * std::sin (a * lumpFreq + 1.3f) + wob * jitter (seed, i % n);
            const juce::Point<float> q (c.x + std::cos (a) * rx * lump, c.y + std::sin (a) * ry * lump);
            if (i == 0) p.startNewSubPath (q); else p.lineTo (q);
        }
        p.closeSubPath();
        return p.createPathWithRoundedCorners (6.0f);
    }

    static void ink (juce::Graphics& g, const juce::Path& p, float w)
    {
        g.setColour (juce::Colours::black);
        g.strokePath (p, juce::PathStrokeType (w, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
    }

    void drawQaeru (juce::Graphics& g, juce::Point<float> c, float S, float wave, float blink, int seed, float t)
    {
        const juce::Colour skin (0xffe9e3d6), skinShade (0xffa79fbd), mouthCol (0xff2a060f);
        const float lw = juce::jmax (2.5f, S * 0.012f);

        // long neck/body dropping into the dark
        juce::Path body;
        body.startNewSubPath (c.x - S * 0.22f, c.y + S * 0.2f);
        body.quadraticTo (c.x - S * 0.32f, c.y + S * 0.9f, c.x - S * 0.4f, c.y + S * 2.0f);
        body.lineTo (c.x + S * 0.42f, c.y + S * 2.0f);
        body.quadraticTo (c.x + S * 0.3f, c.y + S * 0.9f, c.x + S * 0.22f, c.y + S * 0.2f);
        body.closeSubPath();
        g.setGradientFill (juce::ColourGradient (skinShade, c.x, c.y + S * 0.2f, juce::Colour (0xff050407), c.x, c.y + S * 1.2f, false));
        g.fillPath (body);

        // arm (behind head on the right), waving from the elbow
        {
            const juce::Point<float> shoulder (c.x + S * 0.36f, c.y + S * 0.3f);
            const juce::Point<float> elbow = shoulder + juce::Point<float> (S * 0.32f, S * 0.05f);
            const float fore = -2.0f + wave * 0.45f;                     // forearm angle (rad), pointing up-right
            const juce::Point<float> wrist = elbow + juce::Point<float> (std::cos (fore), std::sin (fore)) * (S * 0.42f);
            juce::Path arm; arm.startNewSubPath (shoulder);
            arm.quadraticTo (shoulder.x + S * 0.18f, shoulder.y + S * 0.12f, elbow.x, elbow.y);
            arm.lineTo (wrist);
            g.setColour (juce::Colours::black);
            g.strokePath (arm, juce::PathStrokeType (S * 0.075f + lw * 2.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
            g.setColour (skin.darker (0.08f));
            g.strokePath (arm, juce::PathStrokeType (S * 0.075f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
            // hand: palm + four long toad fingers with round pads
            auto palm = blob (wrist, S * 0.065f, S * 0.06f, 10, 0.05f, seed + 3);
            g.setColour (skin); g.fillPath (palm); ink (g, palm, lw);
            for (int f = 0; f < 4; ++f)
            {
                const float fa = fore - 0.75f + 0.5f * (float) f + wave * 0.12f;
                const float len = S * (0.16f + 0.03f * (float) (f == 1 || f == 2));
                const juce::Point<float> tip = wrist + juce::Point<float> (std::cos (fa), std::sin (fa)) * len;
                juce::Path fp; fp.startNewSubPath (wrist); fp.lineTo (tip + juce::Point<float> (jitter (seed, 40 + f), jitter (seed, 50 + f)) * 1.5f);
                g.setColour (juce::Colours::black); g.strokePath (fp, juce::PathStrokeType (S * 0.024f + lw * 1.6f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
                g.setColour (skin); g.strokePath (fp, juce::PathStrokeType (S * 0.024f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
                auto pad = juce::Rectangle<float> (S * 0.045f, S * 0.045f).withCentre (tip);
                g.setColour (skin); g.fillEllipse (pad);
                g.setColour (juce::Colours::black); g.drawEllipse (pad, lw * 0.8f);
            }
        }

        // head
        auto head = blob (c, S * 0.5f, S * 0.34f, 30, 0.018f, seed);
        g.setGradientFill (juce::ColourGradient (skin, c.x - S * 0.1f, c.y - S * 0.3f, skinShade, c.x + S * 0.2f, c.y + S * 0.35f, false));
        g.fillPath (head);
        // blotches
        g.setColour (skinShade.darker (0.25f).withAlpha (0.55f));
        g.fillPath (blob ({ c.x - S * 0.33f, c.y + S * 0.1f }, S * 0.05f, S * 0.035f, 8, 0.15f, seed + 11));
        g.fillPath (blob ({ c.x + S * 0.3f, c.y - S * 0.05f }, S * 0.035f, S * 0.03f, 8, 0.15f, seed + 12));
        g.fillPath (blob ({ c.x + S * 0.12f, c.y + S * 0.24f }, S * 0.03f, S * 0.02f, 8, 0.15f, seed + 13));
        ink (g, head, lw);

        // blush (cute… ish)
        g.setColour (juce::Colour (0xfff58fb6).withAlpha (0.55f));
        g.fillEllipse (juce::Rectangle<float> (S * 0.12f, S * 0.06f).withCentre ({ c.x - S * 0.32f, c.y + S * 0.03f }));
        g.fillEllipse (juce::Rectangle<float> (S * 0.12f, S * 0.06f).withCentre ({ c.x + S * 0.32f, c.y + S * 0.03f }));

        // bulging eyes on top
        for (int side = -1; side <= 1; side += 2)
        {
            const juce::Point<float> ec (c.x + (float) side * S * 0.23f, c.y - S * 0.27f);
            auto lid = blob (ec, S * 0.19f, S * 0.18f, 18, 0.02f, seed + 20 + side);
            g.setColour (skin); g.fillPath (lid); ink (g, lid, lw);
            auto eye = juce::Rectangle<float> (S * 0.29f, S * 0.27f).withCentre (ec.translated (0, S * 0.01f));
            g.setColour (juce::Colour (0xff060508)); g.fillEllipse (eye);
            // wet highlights
            g.setColour (juce::Colours::white.withAlpha (0.85f));
            g.fillEllipse (juce::Rectangle<float> (S * 0.07f, S * 0.04f).withCentre (eye.getCentre() + juce::Point<float> (-S * 0.06f, -S * 0.07f)));
            g.fillEllipse (juce::Rectangle<float> (S * 0.025f, S * 0.025f).withCentre (eye.getCentre() + juce::Point<float> (S * 0.07f, S * 0.06f)));
            // pinprick pupil that stares at you
            const float twitch = std::sin (t * 23.0f + (float) side) * S * 0.004f;
            g.fillEllipse (juce::Rectangle<float> (S * 0.022f, S * 0.022f).withCentre (eye.getCentre() + juce::Point<float> (twitch, S * 0.01f)));
            // eyelid closing
            if (blink > 0.0f)
            {
                g.saveState();
                g.reduceClipRegion (eye.toNearestInt());
                g.setColour (skin);
                g.fillRect (eye.withHeight (eye.getHeight() * blink));
                g.setColour (juce::Colours::black);
                g.drawLine (eye.getX(), eye.getY() + eye.getHeight() * blink, eye.getRight(), eye.getY() + eye.getHeight() * blink, lw);
                g.restoreState();
            }
        }

        // the grin: very wide, with too many small teeth
        {
            const float mx0 = c.x - S * 0.42f, mx1 = c.x + S * 0.42f, my = c.y + S * 0.04f;
            juce::Path mouth;
            mouth.startNewSubPath (mx0, my);
            mouth.quadraticTo (c.x, my + S * 0.08f, mx1, my);
            mouth.quadraticTo (c.x, my + S * 0.3f, mx0, my);
            mouth.closeSubPath();
            g.setColour (mouthCol); g.fillPath (mouth);
            g.setColour (juce::Colour (0xfff2ecdc));
            const int teeth = 22;
            for (int k = 0; k < teeth; ++k)
            {
                const float a = (float) k / (float) teeth, b = (float) (k + 1) / (float) teeth;
                auto top = [&] (float x) { return my + S * 0.08f * 2.0f * x * (1.0f - x) * 2.0f * 0.5f + S * 0.0f; };
                const float xa = mx0 + (mx1 - mx0) * a, xb = mx0 + (mx1 - mx0) * b;
                juce::Path tooth;
                tooth.addTriangle (xa, top (a), xb, top (b), 0.5f * (xa + xb), top (0.5f * (a + b)) + S * (0.028f + 0.01f * jitter (seed, 70 + k)));
                g.fillPath (tooth);
                if (k > 2 && k < teeth - 3)
                {
                    auto bot = [&] (float x) { return my + S * 0.3f * 2.0f * x * (1.0f - x); };
                    juce::Path bt;
                    bt.addTriangle (xa, bot (a), xb, bot (b), 0.5f * (xa + xb), bot (0.5f * (a + b)) - S * 0.024f);
                    g.fillPath (bt);
                }
            }
            ink (g, mouth, lw);
        }
    }
};
