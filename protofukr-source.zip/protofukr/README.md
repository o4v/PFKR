# protofukr

A lo-fi destruction VST3 effect for FL Studio (and any VST3 host). It combines warping and time-stretching, 2000s-internet codec emulation, tape hiss and transport, transient shaping, compression and two groovebox-style insert FX slots in one window. Every control is a host parameter, so FL Studio can automate all of it.

## Get the plugin (Windows)

You don't need a compiler. GitHub builds it for you:

1. Create a new repository on GitHub and upload this whole folder to it (keep the `.github` folder).
2. Open the repo's **Actions** tab. The *Build protofukr (Windows VST3)* job starts automatically; if it doesn't, click **Run workflow**.
3. When it turns green (about 10–15 min), open the run and download **protofukr-windows-vst3** from *Artifacts*.
4. Unzip it and copy `protofukr.vst3` into `C:\Program Files\Common Files\VST3\`.
5. In FL Studio: **Options ▸ Manage plugins ▸ Find more plugins**. protofukr then appears under *Effects*.

If you push a tag such as `v1.0.0`, the zip is also attached to a GitHub Release.

To build it yourself instead: install Visual Studio 2022 (with the "Desktop development with C++" workload) and CMake, then run:

```
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release --target protofukr_VST3
```

The output is `build/protofukr_artefacts/Release/VST3/protofukr.vst3`.

## Signal flow

```
IN gain → WARP → transient shaper → compressor → FX 1 → FX 2 → TAPE ⇄ LOFI (order switchable) → width / mono → OUT gain
                                                                        (global MIX blends the latency-compensated dry signal)
```

## Sections

### WARP

These are original implementations of the ideas behind Ableton Live's warp modes. No Ableton code is used.

| Algorithm | What it does |
|---|---|
| **Beats** | Plays slices between transients (or 1/16, 1/8, 1/4 grid slices). **Transient Loop** controls what happens when a slice ends early: *Loop Off* goes silent, *Loop Forward* loops the slice's tail forward, *Loop Back-and-Forth* bounces it back and forth. **Envelope** fades each slice, for gated stutters. |
| **Tones** | Pitch-preserving granular stretch. **Grain** sets the grain size. |
| **Texture** | Four-voice granular stretch. **Flux** randomises grain position and length. |
| **Re-Pitch** | Varispeed, where pitch follows speed. Use this for the screwed, tape-slowed sound. |
| **Complex** | Phase-vocoder stretch with transient phase reset. **Pitch** transposes independently of speed. |

There are two sources:

- **Capture** records the live input. Every *Capture Length* (synced to FL's grid), playback restarts at "now" and plays at **Speed**. At 0.75× you get a chopped-and-screwed slowdown that stays in time. **Freeze** loops the last window. **Direction** can be Forward, Reverse or Ping-Pong.
- **Sample** plays a file you load. Drag a WAV/AIFF/FLAC/OGG/MP3 onto the plugin or click *LOAD SAMPLE*. It is locked to FL's transport at Speed × tempo, and plays only while FL plays unless **Free Run** is on. **Smp BPM** is guessed on load; type the real value if the guess is wrong.

### LOFI

Codec types:

- **ZOH**: no-filter sample-and-hold (aliasing crunch). Zero latency.
- **Resample**: band-limited converter (dull, smooth). Zero latency.
- **MP3 '08**: an MDCT coder modelled on low-bitrate MP3 and 2008-era YouTube FLV audio. It produces swirly highs, pre-echo, spectral holes and the encoder low-pass. *YouTube '08 SQ* = 22.05 kHz / 64 kbps / mono.
- **AAC**: the higher `fmt=18` tier. Smoother and wider band.
- **Real '99**: coarse-band streaming codec (metallic, narrow).
- **GSM Phone**: 300–3400 Hz, mu-law crunch.

The **Rate** (500 Hz–48 kHz), **Bitrate** (8–320 kbps) and **Bits** (1–24) faders have typeable readouts: click the green number and type an exact value (e.g. `22050` or `22.05k`). The ▼ menus next to them offer common values. **Swirl** adds time-varying "underwater" allocation artifacts. **Frame** sets the block size: longer frames smear more; *Low Latency* is about 6 ms. MDCT codecs report their latency to FL, so plugin delay compensation keeps everything in sync.

### TAPE

Hiss voicings:

- Cheap Ferric (UR-ish, bright and gritty)
- Ferric Normal
- Chrome CrO2
- Metal
- Microcassette
- VHS Linear (with head-switch buzz)
- CRT Broadcast (static plus 15.734 kHz flyback whine)
- Vinyl Dust

**Hiss Sidechain** sets what the hiss level follows:

- Constant
- All Input
- Duck Input (hiss rises in the gaps)
- Low Band (kick)
- High Band (hats)
- Sidechain Bus (the plugin's external sidechain input)

**Transport** adds:

- **Wow, flutter and drive.**
- **Azimuth:** tape-head misalignment. The left channel lags the right by up to 1 ms, giving phasey, smeared highs.
- **HF Cut and Bump:** worn heads and dub-generation high loss, with a resonant head bump.

The **Memphis Dub Tape** hiss is a rumbly, dark cassette noise bed with mains hum.

### DYNAMICS

**Transient** modes:

- Sharp (crisp high band)
- Fat (low band plus saturation)
- Balanced
- Punch
- Snap
- Smack

Each mode has Attack, Sustain and Focus controls.

The **Compressor** has six styles: Clean VCA, Opto, FET, Glue, Brick and Pump. *PRESETS* offers: Screw Tape Glue, Soundcloud Smash, Lofi Bus, Vapor Pump, Drum Punch, Parallel NY Crush, Gentle Opto, Vocal Sit and Boom-Bap Knock.

### LARP RESAMPLER (Qaeru Mode)

Makes audio sound like it was chopped into many slices on a hardware sampler and pieced back into a loop. It adds no latency.

- **Slice:** 1/1 to 1/64, plus 1/8T and 1/16T, synced to FL's grid.
- **Grain:** micro-chops inside each slice. This is the "million chops" chatter; 0 turns it off.
- **Slop:** sloppy chop starts (up to 25 ms).
- **Smear:** each slice drags behind and catches up, a Gross-Beat-style wobble without real pitch shifting.
- **Repeat:** chance a slice replays the previous one.
- **Chop Dip:** how hard each cut dips.
- **Ring / Ring Tune:** a tuned metallic comb that rings while material plays, for the flute shimmer.
- **Hardware:** MPC60, MPC3000, SP-1200, S950, MPC2000XL-style or Dusty Sampler colour.

### OUTPUT

- **Bass Keep / Bass Lift:** everything below Bass Keep skips the Larp, Tape and Lofi damage (crush, chops, wow, hiss) and comes back clean. It is delay-matched and lifted by Bass Lift, so the 808s stay fluent under the grit.
- **Width** and **Bass Mono:** everything below the set frequency becomes mono, for a tight, compressed-sounding low end with a wider top.
- **Scare Boost:** see "The secret" below.

### INSERT FX (×2)

These are groovebox-style performance effects in the spirit of the SP-404 / SP-202 banks:

| Group | Effects |
|---|---|
| EQ and filters | Isolator, Filter+Drive, Super Filter, Auto Wah |
| Lo-fi and sims | Lo-Fi, Vinyl Sim A/B, Cassette Sim, Crusher |
| Performance | Stutter (beat-synced repeat with chance and gate), DJ Looper (−2× to +2×, reverse), Downer, Tape Stop / Back Spin |
| Delay and reverb | Sync Delay, Tape Echo, Reverb |
| Modulation | Chorus, Flanger, Phaser, Slicer, Tremolo/Pan |
| Tone and pitch | Ring Mod, Resonator, Overdrive, Distortion, Pitch Shift, Bell EQ |

Each effect has three macro controls (A/B/C), which are relabelled per effect, plus Balance. Stutter, DJ Looper and Tape Stop are made to be automated: for example, automate *Hold* or *Trigger* in FL.

### Global

- Stereo / Mono switch, Width (0–200 %)
- In / Out gain
- Global Mix (dry is delay-compensated)
- Chain order: Tape → Codec (hiss gets crushed, like a tape ripped to YouTube) or Codec → Tape

## Factory presets

**Memphis Mode v1–v4:** each is matched to a reference track, by measuring the track and fitting the plugin to it.

| Preset | Reference | What it recreates |
|---|---|---|
| v1 (Criminal) | Criminal Manne – Fuck What You Claim | 26 kHz 12-bit grit, highs gone above about 3.6 kHz, 0.23 ms azimuth, loud limited bus, rumbly hiss |
| v2 (Manson) | IlIlIlIlIlIIIlII – Manson Family | 16 kHz sample-rate brickwall at 7.9 kHz, bright mids right up to the wall, quieter bed |
| v3 (Hoe Don't Violate) | IlIlIlIlIlIIIlII – Hoe Don't Violate | ~24 kHz resample, scooped 1.5 kHz, 7 kHz head bump, wide phasey stereo |
| v4 (Project Born) | DJ Big Mac – Project Born | early 3.9 kHz roll-off, loud hiss bed, 16 kHz rip cutoff |

All four keep the bass clean with Bass Keep.

Larp: Million Chops (MPC60), Larp: Couch Grain 1/32 (Qaeru), Larp: SP-1200 Chop Loop, Larp: Flute Ring, Beat Machine: Mono Knock, Beat Machine: Basement Glue, Beat Machine: Dusty Bus, Init, YouTube '08 SQ, YouTube '08 HQ, Signalwave Broadcast, Mediafire Rip, Plaza Slowdown, Chopped & Screwed, Maxell Tape Dub, Soundcloud Smash, Late Night Sleepcore, Glitter Static, Mystic Dust (Texture), Mallsoft Hallway, RealPlayer '99, Phone Call, Beats Stutter Gate, Tape Stop Throw.

The presets also appear in FL's preset menu on the plugin wrapper.

## FL Studio tips

- **Automation:** move any control, then use *Tools ▸ Last tweaked ▸ Create automation clip*, or right-click it in the wrapper's *Browse parameters* list. All 69 parameters are exposed.
- **Sidechain the hiss:** protofukr has a stereo *Sidechain* input. Route the source track to protofukr's mixer insert as a sidechain, assign it to the plugin's sidechain input in the wrapper's processing/port settings, then set *Hiss Sidechain* to *Sidechain Bus*.
- **Latency:** the MP3/AAC/Real/GSM codecs use 6–93 ms of look-behind, depending on Frame. It is reported to FL, so leave PDC on.
- **CPU and RAM:** everything is pre-allocated when playback starts. Nothing allocates on the audio thread. The capture buffer is about 10 s, and loaded samples are capped at 10 min.

## The secret

Click the little frog in the top-left corner three times quickly, or click the window and type `qaeru`. He says hi. With **Scare Boost** on, the output is slammed to full scale for 0.3 s when he lunges. It is hard-capped at 0 dBFS, but that is still as loud as digital audio gets, so mind your monitor volume (or switch Scare Boost off). If FL's *Typing keyboard to piano* is on and steals the keys, toggle it off first (the frog works either way).

## Window size

Drag the bottom-right corner to resize the window (half size up to double size). It keeps its shape and stays sharp, and protofukr remembers the size in your project.

## Credits

Fonts: Dela Gothic One and VT323 (SIL Open Font License; see `Resources/OFL-*.txt`). Built with JUCE 8.
