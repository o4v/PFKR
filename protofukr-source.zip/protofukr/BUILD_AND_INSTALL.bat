@echo off
setlocal
title protofukr - build and install

:: ---- ask for admin rights (needed to install tools and write to the VST3 folder)
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Asking for administrator permission...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

cd /d "%~dp0"
if not exist "CMakeLists.txt" (
    echo This file must be inside the unzipped protofukr folder, next to CMakeLists.txt.
    pause
    exit /b 1
)

where winget >nul 2>&1
if %errorlevel% neq 0 (
    echo winget was not found. Install "App Installer" from the Microsoft Store, then run this again.
    pause
    exit /b 1
)

echo.
echo === [1/5] Installing CMake ===
winget install -e --id Kitware.CMake --silent --accept-package-agreements --accept-source-agreements

echo.
echo === [2/5] Installing Git ===
winget install -e --id Git.Git --silent --accept-package-agreements --accept-source-agreements

echo.
echo === [3/5] Installing Visual Studio C++ Build Tools ===
echo     This is a big download (a few GB) and can take 20-40 minutes. Leave this window open.
winget install -e --id Microsoft.VisualStudio.2022.BuildTools --silent --accept-package-agreements --accept-source-agreements --override "--quiet --wait --norestart --nocache --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended"

set "PATH=%ProgramFiles%\CMake\bin;%ProgramFiles%\Git\cmd;%PATH%"

echo.
echo === [4/5] Building protofukr (10-15 minutes the first time) ===
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
if %errorlevel% neq 0 goto fail
cmake --build build --config Release --target protofukr_VST3 --parallel
if %errorlevel% neq 0 goto fail

echo.
echo === [5/5] Installing into your VST3 folder ===
set "DEST=%CommonProgramFiles%\VST3"
if not exist "%DEST%" mkdir "%DEST%"
robocopy "build\protofukr_artefacts\Release\VST3\protofukr.vst3" "%DEST%\protofukr.vst3" /E /NFL /NDL /NJH /NJS >nul
if %errorlevel% geq 8 goto fail

echo.
echo ============================================================
echo  Done! protofukr is installed in:
echo    %DEST%\protofukr.vst3
echo  In FL Studio: Options ^> Manage plugins ^> Find more plugins
echo ============================================================
pause
exit /b 0

:fail
echo.
echo ============================================================
echo  Something went wrong. Scroll up, copy the error lines,
echo  and paste them to Claude.
echo ============================================================
pause
exit /b 1
